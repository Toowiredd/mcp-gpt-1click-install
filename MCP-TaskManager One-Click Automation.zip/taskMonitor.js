const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class TaskMonitor {
  constructor(options = {}) {
    this.options = {
      logDir: './logs',
      statePath: './state/monitor.json',
      maxRetries: 3,
      retryDelay: 2000,
      ...options
    };
    
    this.tasks = new Map();
    this.activeCount = 0;
    this.failureCount = 0;
    
    // Create required directories
    [this.options.logDir, path.dirname(this.options.statePath)].forEach(dir => {
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    });
    
    this.loadState();
    
    // Setup regular state persistence
    this.saveInterval = setInterval(() => this.saveState(), 30000);
    
    // Handle process termination
    process.on('SIGINT', () => this.shutdown());
    process.on('SIGTERM', () => this.shutdown());
  }
  
  generateTaskId() {
    return crypto.randomBytes(8).toString('hex');
  }
  
  logEvent(taskId, level, message, data = {}) {
    const logEntry = {
      timestamp: new Date().toISOString(),
      taskId: taskId || 'system',
      level,
      message,
      ...data
    };
    
    const logFile = path.join(
      this.options.logDir,
      `tasks-${new Date().toISOString().split('T')[0]}.log`
    );
    
    try {
      fs.appendFileSync(
        logFile,
        JSON.stringify(logEntry) + '\n'
      );
    } catch (err) {
      console.error('Failed to write log entry:', err);
    }
    
    if (level === 'error' || level === 'warn') {
      console[level](`[${logEntry.timestamp}] ${taskId}: ${message}`);
    }
  }
  
  startTask(taskType, params = {}, options = {}) {
    const taskId = options.id || this.generateTaskId();
    
    if (this.tasks.has(taskId)) {
      throw new Error(`Task ID ${taskId} already exists`);
    }
    
    const task = {
      id: taskId,
      type: taskType,
      params,
      status: 'pending',
      createdAt: new Date().toISOString(),
      attempts: 0,
      ...options
    };
    
    this.tasks.set(taskId, task);
    this.activeCount++;
    this.logEvent(taskId, 'info', `Task created: ${taskType}`, { params });
    
    return taskId;
  }
  
  updateTask(taskId, status, result = null) {
    if (!this.tasks.has(taskId)) {
      this.logEvent(null, 'warn', `Attempted to update non-existent task: ${taskId}`);
      return false;
    }
    
    const task = this.tasks.get(taskId);
    const previousStatus = task.status;
    
    task.status = status;
    task.updatedAt = new Date().toISOString();
    
    if (status === 'completed') {
      task.completedAt = task.updatedAt;
      task.result = result;
      this.activeCount--;
      this.logEvent(taskId, 'info', 'Task completed', { result });
    }
    
    if (status === 'failed') {
      task.failedAt = task.updatedAt; 
      task.error = result;
      task.attempts++;
      this.failureCount++;
      
      this.logEvent(taskId, 'error', 'Task failed', { error: result });
      
      // Auto-retry logic
      if (task.attempts < this.options.maxRetries) {
        setTimeout(() => {
          this.retryTask(taskId);
        }, this.options.retryDelay * task.attempts);
        
        task.status = 'pending_retry';
        this.logEvent(taskId, 'info', `Scheduled retry ${task.attempts}/${this.options.maxRetries}`);
      } else {
        this.activeCount--;
        this.logEvent(taskId, 'error', 'Task failed permanently after max retries');
      }
    }
    
    // Trigger state save on important status changes
    if (['completed', 'failed'].includes(status)) {
      this.saveState();
    }
    
    return true;
  }
  
  retryTask(taskId) {
    if (!this.tasks.has(taskId)) {
      return false;
    }
    
    const task = this.tasks.get(taskId);
    if (task.status !== 'pending_retry') {
      return false;
    }
    
    task.status = 'retrying';
    this.logEvent(taskId, 'info', `Retrying task (attempt ${task.attempts})`);
    
    return taskId;
  }
  
  getTask(taskId) {
    return this.tasks.get(taskId);
  }
  
  getAllTasks(filter = {}) {
    const result = [];
    
    this.tasks.forEach(task => {
      let match = true;
      
      // Apply filters
      Object.entries(filter).forEach(([key, value]) => {
        if (task[key] !== value) match = false;
      });
      
      if (match) result.push({...task});
    });
    
    return result;
  }
  
  loadState() {
    try {
      if (fs.existsSync(this.options.statePath)) {
        const state = JSON.parse(fs.readFileSync(this.options.statePath, 'utf8'));
        
        // Restore tasks
        if (state.tasks) {
          state.tasks.forEach(task => {
            this.tasks.set(task.id, task);
            if (['pending', 'running', 'retrying'].includes(task.status)) {
              this.activeCount++;
            }
          });
        }
        
        this.failureCount = state.failureCount || 0;
        this.logEvent(null, 'info', `State loaded: ${this.tasks.size} tasks, ${this.activeCount} active`);
      }
    } catch (err) {
      this.logEvent(null, 'error', `Failed to load state: ${err.message}`);
    }
  }
  
  saveState() {
    try {
      const state = {
        timestamp: new Date().toISOString(),
        tasks: Array.from(this.tasks.values()),
        activeCount: this.activeCount,
        failureCount: this.failureCount
      };
      
      // Create backup of previous state
      if (fs.existsSync(this.options.statePath)) {
        fs.copyFileSync(
          this.options.statePath, 
          `${this.options.statePath}.bak`
        );
      }
      
      fs.writeFileSync(
        this.options.statePath,
        JSON.stringify(state, null, 2)
      );
    } catch (err) {
      this.logEvent(null, 'error', `Failed to save state: ${err.message}`);
    }
  }
  
  shutdown() {
    clearInterval(this.saveInterval);
    this.saveState();
    this.logEvent(null, 'info', 'TaskMonitor shutting down');
  }
}

module.exports = TaskMonitor;