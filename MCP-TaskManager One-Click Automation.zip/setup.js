// SETUP: One-click automated installation for MCP-TaskManager
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// Create directory structure
const dirs = [
  './tasks', 
  './completed', 
  './failed', 
  './logs', 
  './public',
  './windsurf',
  './backups'
];

console.log('Creating directory structure...');
dirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o755 });
    console.log(`Created: ${dir}`);
  }
});

// Create package.json if it doesn't exist
if (!fs.existsSync('./package.json')) {
  const pkg = {
    "name": "mcp-taskmanager",
    "version": "1.0.0",
    "description": "MCP TaskManager with WindSurf integration",
    "main": "index.js",
    "scripts": {
      "start": "node index.js"
    },
    "dependencies": {}
  };
  
  fs.writeFileSync('./package.json', JSON.stringify(pkg, null, 2));
  console.log('Created package.json');
}

// Install required dependencies
console.log('Installing dependencies...');
exec('npm install --save uuid express', (error, stdout, stderr) => {
  if (error) {
    console.error(`Error installing dependencies: ${error.message}`);
    return;
  }
  
  console.log('Dependencies installed successfully');
  console.log('Setup complete! Run with: node index.js');
});

// Create welcome page
const welcomeHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>MCP TaskManager Installed</title>
  <style>
    body { font-family: Arial; padding: 20px; max-width: 800px; margin: 0 auto; line-height: 1.6; }
    .card { background: #f5f5f5; padding: 20px; border-radius: 8px; margin: 20px 0; }
    .success { background: #d4edda; border-left: 4px solid #28a745; }
    pre { background: #f8f9fa; padding: 10px; overflow: auto; border-radius: 4px; }
  </style>
</head>
<body>
  <h1>MCP TaskManager Automation System</h1>
  <div class="card success">
    <h2>Installation Complete</h2>
    <p>Your automation system has been successfully installed.</p>
  </div>
  
  <div class="card">
    <h2>Quick Start</h2>
    <p>Open a terminal and run:</p>
    <pre>node index.js</pre>
    <p>Then open <a href="http://localhost:3000/dashboard">http://localhost:3000/dashboard</a> in your browser.</p>
  </div>
  
  <div class="card">
    <h2>WindSurf Integration</h2>
    <p>Point WindSurf to use the <code>./windsurf</code> directory for Cascade AI integration.</p>
  </div>
</body>
</html>`;

fs.writeFileSync('./public/index.html', welcomeHtml);
console.log('Created welcome page');