// Cascade AI Agent Interface
const path = require('path');
const fs = require('fs');
const { createCommand, getResponses } = require('./windsurfIntegration');

class CascadeAgent {
  constructor() {
    this.pendingCommands = new Map();
    this.responseCache = new Map();
    this.responseCheckInterval = 2000; // 2 seconds
  }

  async createTask(taskType, params) {
    this.validateTaskType(taskType);
    this.validateParams(params);
    
    const commandId = createCommand('create_task', { 
      taskType, 
      params
    });
    
    this.pendingCommands.set(commandId, {
      action: 'create_task',
      timestamp: Date.now()
    });
    
    return this.waitForResponse(commandId);
  }

  async getTaskStatus(taskId) {
    if (!taskId || typeof taskId !== 'string') {
      throw new Error('Invalid task ID');
    }
    
    const commandId = createCommand('get_status', { taskId });
    
    this.pendingCommands.set(commandId, {
      action: 'get_status',
      timestamp: Date.now()
    });
    
    return this.waitForResponse(commandId);
  }

  async getTaskHistory() {
    const commandId = createCommand('get_history');
    
    this.pendingCommands.set(commandId, {
      action: 'get_history',
      timestamp: Date.now()
    });
    
    return this.waitForResponse(commandId);
  }
  
  validateTaskType(taskType) {
    const validTypes = ['process', 'query', 'report', 'backup', 'monitor'];
    if (!validTypes.includes(taskType)) {
      throw new Error(`Invalid task type: ${taskType}. Must be one of: ${validTypes.join(', ')}`);
    }
  }
  
  validateParams(params) {
    if (!params || typeof params !== 'object') {
      throw new Error('Task parameters must be an object');
    }
    
    // Sanitize parameters to prevent injection attacks
    for (const [key, value] of Object.entries(params)) {
      if (typeof value === 'string') {
        // Check for potential command injection characters
        if (/[;&|`$]/.test(value)) {
          throw new Error(`Invalid characters in parameter ${key}`);
        }
      }
    }
  }

  async waitForResponse(commandId, timeout = 30000) {
    return new Promise((resolve, reject) => {
      const start = Date.now();
      
      const checkResponse = () => {
        try {
          const responses = getResponses();
          
          // Find matching response
          const response = responses.find(r => r.id === commandId);
          
          if (response) {
            // Store in cache and remove from pending
            this.responseCache.set(commandId, response);
            this.pendingCommands.delete(commandId);
            
            if (response.status === 'error') {
              reject(new Error(response.error));
            } else {
              resolve(response);
            }
            return;
          }
          
          // Check timeout
          if (Date.now() - start > timeout) {
            this.pendingCommands.delete(commandId);
            reject(new Error('Response timeout'));
            return;
          }
          
          // Check again after interval
          setTimeout(checkResponse, this.responseCheckInterval);
        } catch (err) {
          reject(new Error(`Error waiting for response: ${err.message}`));
        }
      };
      
      // Start checking
      setTimeout(checkResponse, this.responseCheckInterval);
    });
  }
  
  // Helper methods for Cascade AI for common tasks
  
  async monitorSystemResources() {
    return this.createTask('monitor', {
      resources: ['memory', 'cpu', 'disk'],
      interval: 'once'
    });
  }
  
  async createBackup(target = 'database', destination = './backups') {
    return this.createTask('backup', {
      target,
      destination,
      compress: true
    });
  }
  
  async generateReport(reportType = 'system', format = 'json') {
    return this.createTask('report', {
      type: reportType,
      format,
      includeDetails: true
    });
  }
}

module.exports = new CascadeAgent();