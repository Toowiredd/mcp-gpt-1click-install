// CORE: Main entry point with automatic error recovery
const fs = require('fs');
const path = require('path');
const express = require('express');
const TaskManager = require('./taskManager');
const WindsurfIntegration = require('./windsurfIntegration');

// Initialize server
const app = express();
const PORT = process.env.PORT || 3000;

// Configure static file serving
app.use('/public', express.static('public'));
app.use(express.json());

// Redirect root to dashboard
app.get('/', (req, res) => {
  res.redirect('/dashboard');
});

// Dashboard route
app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// API route for task creation
app.post('/api/tasks', (req, res) => {
  try {
    const { type, params, metadata } = req.body;
    const taskId = TaskManager.createTask(type, params, metadata);
    res.json({ success: true, taskId });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// API route for task status
app.get('/api/tasks/:taskId', (req, res) => {
  try {
    const taskId = req.params.taskId;
    const status = TaskManager.getTaskStatus(taskId);
    res.json({ success: true, task: status });
  } catch (err) {
    res.status(404).json({ success: false, error: err.message });
  }
});

// SAFETY: Global error handler
app.use((err, req, res, next) => {
  console.error(`API Error: ${err.message}`);
  res.status(500).json({ success: false, error: 'Server error' });
});

// Start server
const server = app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Dashboard available at http://localhost:${PORT}/dashboard`);
});

// SAFETY: Handle unhandled exceptions
process.on('uncaughtException', (err) => {
  console.error('CRITICAL ERROR:', err.message);
  fs.appendFileSync(
    path.join(__dirname, 'logs', 'crash.log'),
    `${new Date().toISOString()} - CRASH: ${err.message}\n${err.stack}\n`
  );
});

// SAFETY: Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Promise Rejection:', reason);
  fs.appendFileSync(
    path.join(__dirname, 'logs', 'errors.log'),
    `${new Date().toISOString()} - UNHANDLED REJECTION: ${reason}\n`
  );
});

// SAFETY: Handle shutdown gracefully
process.on('SIGTERM', () => {
  console.log('Shutdown signal received, closing server...');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});