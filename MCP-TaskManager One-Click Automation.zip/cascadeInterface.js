const fs = require('fs');
const path = require('path');

class CascadeInterface {
  constructor(taskMonitor, taskExecutor, options = {}) {
    this.taskMonitor = taskMonitor;
    this.taskExecutor = taskExecutor;
    
    this.options = {
      watchDir: './cascade',
      responseDir: './cascade/responses',
      commandFile: './cascade/commands.json',
      heartbeatInterval: 10000,
      ...options
    };
    
    // Create directories
    [this.options.watchDir, this.options.responseDir].forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    });
    
    // Initialize command file if doesn't exist
    if (!fs.existsSync(this.options.commandFile)) {
      fs.writeFileSync(this.options.commandFile, JSON.stringify([]));
    }
    
    // Start watching for command file changes
    this.startWatching();
    
    // Heartbeat to let WindSurf know we're alive
    this.heartbeatInterval = setInterval(() => this.sendHeartbeat(), 
      this.options.heartbeatInterval);
      
    // Handle graceful shutdown
    process.on('SIGINT', () => this.shutdown());
    process.on('SIGTERM', () => this.shutdown());
  }
  
  startWatching() {
    // Watch command file for changes
    fs.watch(this.options.commandFile, () => {
      this.processCommands();
    });
    
    // Watch task directory for new task files
    fs.watch(this.options.watchDir, (eventType, filename) => {
      if (eventType === 'rename' && filename && filename.startsWith('task-') && filename.endsWith('.json')) {
        setTimeout(() => this.processTaskFile(filename), 100);
      }
    });
  }
  
  processCommands() {
    try {
      // Read and parse command file
      const commandsRaw = fs.readFileSync(this.options.commandFile, 'utf8');
      const commands = JSON.parse(commandsRaw);
      
      if (!Array.isArray(commands) || commands.length === 0) return;
      
      // Process each command
      const processedCommands = [];
      
      commands.forEach(cmd => {
        try {
          if (!cmd.id || !cmd.type) {
            this.logError('Invalid command structure', cmd);
            return;
          }
          
          const result = this.executeCommand(cmd);
          processedCommands.push(cmd.id);
          
          // Save response
          this.saveResponse(cmd.id, result);
        } catch (err) {
          this.logError(`Command ${cmd.id} failed: ${err.message}`, cmd);
          this.saveResponse(cmd.id, { error: err.message });
        }
      });
      
      // Remove processed commands
      const remainingCommands = commands.filter(cmd => !processedCommands.includes(cmd.id));
      fs.writeFileSync(this.options.commandFile, JSON.stringify(remainingCommands));
    } catch (err) {
      this.logError(`Error processing commands: ${err.message}`);
    }
  }
  
  processTaskFile(filename) {
    const filePath = path.join(this.options.watchDir, filename);
    
    try {
      if (fs.existsSync(filePath)) {
        const taskData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        
        // Validate task data
        if (!taskData.type) {
          throw new Error('Missing task type');
        }
        
        // Queue task for execution
        const taskId = this.taskExecutor.queueTask(
          taskData.type,
          taskData.params || {},
          taskData.options || {}
        );
        
        // Move file to prevent reprocessing
        fs.renameSync(
          filePath,
          path.join(this.options.watchDir, `processing-${filename}`)
        );
        
        // Save response with task ID
        this.saveResponse(
          path.basename(filename, '.json'),
          { success: true, taskId }
        );
      }
    } catch (err) {
      this.logError(`Error processing task file ${filename}: ${err.message}`);
      
      // Move to error folder
      try {
        fs.renameSync(
          filePath,
          path.join(this.options.watchDir, `error-${filename}`)
        );
      } catch (moveErr) {
        // Ignore move errors
      }
    }
  }
  
  executeCommand(cmd) {
    switch (cmd.type) {
      case 'GET_TASK':
        return this.handleGetTask(cmd);
      case 'GET_ALL_TASKS':
        return this.handleGetAllTasks(cmd);
      case 'CANCEL_TASK':
        return this.handleCancelTask(cmd);
      case 'GET_STATUS':
        return this.handleGetStatus(cmd);
      default:
        throw new Error(`Unknown command type: ${cmd.type}`);
    }
  }
  
  handleGetTask(cmd) {
    const taskId = cmd.params?.taskId;
    if (!taskId) {
      throw new Error('No taskId provided');
    }
    
    const task = this.taskMonitor.getTask(taskId);
    if (!task) {
      throw new Error(`Task ${taskId} not found`);
    }
    
    return { task };
  }
  
  handleGetAllTasks(cmd) {
    const filter = cmd.params?.filter || {};
    const tasks = this.taskMonitor.getAllTasks(filter);
    
    return { 
      tasks,
      count: tasks.length
    };
  }
  
  handleCancelTask(cmd) {
    const taskId = cmd.params?.taskId;
    if (!taskId) {
      throw new Error('No taskId provided');
    }
    
    // Implementation would need task cancellation logic
    // For now, just returning an error
    throw new Error('Task cancellation not implemented');
  }
  
  handleGetStatus(cmd) {
    return {
      status: 'active',
      queueStats: this.taskExecutor.getQueueStatus(),
      activeExecutions: this.taskExecutor.getActiveExecutions().length,
      timestamp: new Date().toISOString()
    };
  }
  
  saveResponse(cmdId, data) {
    try {
      const responseFile = path.join(
        this.options.responseDir,
        `response-${cmdId}.json`
      );
      
      fs.writeFileSync(
        responseFile,
        JSON.stringify({
          id: cmdId,
          timestamp: new Date().toISOString(),
          ...data
        }, null, 2)
      );
    } catch (err) {
      this.logError(`Error saving response for ${cmdId}: ${err.message}`);
    }
  }
  
  sendHeartbeat() {
    try {
      fs.writeFileSync(
        path.join(this.options.watchDir, 'heartbeat.json'),
        JSON.stringify({
          status: 'active',
          timestamp: new Date().toISOString(),
          pid: process.pid
        })
      );
    } catch (err) {
      console.error('Failed to send heartbeat:', err);
    }
  }
  
  logError(message, data = null) {
    const logEntry = {
      timestamp: new Date().toISOString(),
      message,
      data
    };
    
    console.error(`[CascadeInterface] ${message}`);
    
    try {
      fs.appendFileSync(
        path.join(this.options.watchDir, 'errors.log'),
        JSON.stringify(logEntry) + '\n'
      );
    } catch (err) {
      // Can't log to file, console only
      console.error('Additionally failed to write to error log');
    }
  }
  
  shutdown() {
    clearInterval(this.heartbeatInterval);
    console.log('Cascade interface shutting down');
  }
}

module.exports = CascadeInterface;