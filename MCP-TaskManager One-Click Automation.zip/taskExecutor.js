const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

class TaskExecutor {
  constructor(taskMonitor, options = {}) {
    this.taskMonitor = taskMonitor;
    this.options = {
      workDir: './workspace',
      maxConcurrent: 5,
      timeout: 300000, // 5 min default timeout
      ...options
    };
    
    this.activeExecutions = new Map();
    this.taskQueue = [];
    this.isBusy = false;
    
    // Create workspace directory
    if (!fs.existsSync(this.options.workDir)) {
      fs.mkdirSync(this.options.workDir, { recursive: true });
    }
  }
  
  queueTask(taskType, params = {}, options = {}) {
    // Create task in monitor
    const taskId = this.taskMonitor.startTask(taskType, params, options);
    
    // Add to execution queue
    this.taskQueue.push({
      taskId,
      taskType,
      params,
      options,
      queuedAt: new Date().toISOString()
    });
    
    // Start processing queue if not already running
    if (!this.isBusy) {
      this.processQueue();
    }
    
    return taskId;
  }
  
  async processQueue() {
    if (this.isBusy || this.taskQueue.length === 0) return;
    
    this.isBusy = true;
    
    try {
      // Process tasks until queue is empty or at max concurrent
      while (this.taskQueue.length > 0 && this.activeExecutions.size < this.options.maxConcurrent) {
        const task = this.taskQueue.shift();
        this.executeTask(task.taskId);
      }
    } finally {
      this.isBusy = false;
    }
  }
  
  async executeTask(taskId) {
    const task = this.taskMonitor.getTask(taskId);
    if (!task) return false;
    
    // Task is already running
    if (this.activeExecutions.has(taskId)) return false;
    
    // Update task status
    task.status = 'running';
    task.startedAt = new Date().toISOString();
    
    // Create working directory for this task
    const taskWorkDir = path.join(this.options.workDir, taskId);
    if (!fs.existsSync(taskWorkDir)) {
      fs.mkdirSync(taskWorkDir, { recursive: true });
    }
    
    // Save task details to work directory
    fs.writeFileSync(
      path.join(taskWorkDir, 'task.json'),
      JSON.stringify(task, null, 2)
    );
    
    // Track execution with timeout
    const timeoutId = setTimeout(() => {
      this.handleTaskTimeout(taskId);
    }, task.options?.timeout || this.options.timeout);
    
    this.activeExecutions.set(taskId, { 
      taskId,
      startTime: Date.now(),
      timeoutId
    });
    
    try {
      const result = await this.runTaskImplementation(task, taskWorkDir);
      this.completeTask(taskId, result);
    } catch (error) {
      this.failTask(taskId, error.message || 'Unknown error');
    }
    
    return true;
  }
  
  async runTaskImplementation(task, workDir) {
    // Dispatch to appropriate handler based on task type
    switch (task.type) {
      case 'SYSTEM_MONITOR':
        return this.runSystemMonitorTask(task, workDir);
      case 'DB_BACKUP':
        return this.runDbBackupTask(task, workDir);
      case 'FILE_PROCESS':
        return this.runFileProcessTask(task, workDir);
      case 'SCRIPT_EXEC':
        return this.runScriptExecTask(task, workDir);
      default:
        throw new Error(`Unknown task type: ${task.type}`);
    }
  }
  
  runSystemMonitorTask(task, workDir) {
    return new Promise((resolve, reject) => {
      const { servers = [], metrics = [] } = task.params;
      
      if (!servers.length) {
        return reject(new Error('No servers specified'));
      }
      
      // Collect server metrics
      const results = {};
      let completed = 0;
      let failed = 0;
      
      servers.forEach(server => {
        // Mock system monitoring (replace with actual monitoring code)
        setTimeout(() => {
          try {
            const serverMetrics = {};
            metrics.forEach(metric => {
              // Generate mock metric data
              serverMetrics[metric] = Math.floor(Math.random() * 100);
            });
            
            results[server] = serverMetrics;
            completed++;
            
            // Check if all servers processed
            if (completed + failed === servers.length) {
              resolve({
                timestamp: new Date().toISOString(),
                metrics: results,
                totalServers: servers.length,
                completedServers: completed,
                failedServers: failed
              });
            }
          } catch (err) {
            failed++;
            // Continue with other servers
          }
        }, 500);
      });
      
      // Safety timeout
      setTimeout(() => {
        if (completed + failed < servers.length) {
          resolve({
            timestamp: new Date().toISOString(),
            metrics: results,
            totalServers: servers.length,
            completedServers: completed,
            failedServers: failed,
            timedOut: true
          });
        }
      }, task.options?.timeout || 30000);
    });
  }
  
  runDbBackupTask(task, workDir) {
    return new Promise((resolve, reject) => {
      const { database, compressionLevel, destination } = task.params;
      
      if (!database) {
        return reject(new Error('No database specified'));
      }
      
      if (!destination) {
        return reject(new Error('No backup destination specified'));
      }
      
      // Log backup start
      fs.writeFileSync(
        path.join(workDir, 'backup.log'),
        `Backup started at ${new Date().toISOString()}\n`
      );
      
      // Mock DB backup process
      setTimeout(() => {
        const backupFilename = `backup-${database}-${Date.now()}.bak`;
        
        fs.appendFileSync(
          path.join(workDir, 'backup.log'),
          `Backup completed. File: ${backupFilename}\n`
        );
        
        resolve({
          success: true,
          database,
          destination,
          filename: backupFilename,
          timestamp: new Date().toISOString(),
          compressionLevel
        });
      }, 3000);
    });
  }
  
  runFileProcessTask(task, workDir) {
    return new Promise((resolve, reject) => {
      const { inputFiles, outputPath, operation } = task.params;
      
      if (!inputFiles || !Array.isArray(inputFiles) || inputFiles.length === 0) {
        return reject(new Error('No input files specified'));
      }
      
      if (!operation) {
        return reject(new Error('No file operation specified'));
      }
      
      // Mock file processing
      setTimeout(() => {
        const results = inputFiles.map(file => ({
          file,
          processed: true,
          outputFile: path.join(outputPath || '.', `processed-${path.basename(file)}`)
        }));
        
        resolve({
          success: true,
          operation,
          processedFiles: results.length,
          results
        });
      }, 2000);
    });
  }
  
  runScriptExecTask(task, workDir) {
    return new Promise((resolve, reject) => {
      const { script, args = [], env = {} } = task.params;
      
      if (!script) {
        return reject(new Error('No script specified'));
      }
      
      // Write script to file
      const scriptFile = path.join(workDir, 'script.js');
      fs.writeFileSync(scriptFile, script);
      
      // Execute script in separate process
      const child = spawn('node', [scriptFile, ...args], {
        cwd: workDir,
        env: { ...process.env, ...env },
      });
      
      let stdout = '';
      let stderr = '';
      
      child.stdout.on('data', (data) => {
        stdout += data;
        fs.appendFileSync(path.join(workDir, 'stdout.log'), data);
      });
      
      child.stderr.on('data', (data) => {
        stderr += data;
        fs.appendFileSync(path.join(workDir, 'stderr.log'), data);
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          resolve({
            success: true,
            exitCode: code,
            output: stdout
          });
        } else {
          reject(new Error(`Script failed with code ${code}: ${stderr}`));
        }
      });
    });
  }
  
  completeTask(taskId, result) {
    // Clear timeout if exists
    if (this.activeExecutions.has(taskId)) {
      clearTimeout(this.activeExecutions.get(taskId).timeoutId);
      this.activeExecutions.delete(taskId);
    }
    
    // Update task state
    this.taskMonitor.updateTask(taskId, 'completed', result);
    
    // Process next tasks
    if (this.taskQueue.length > 0) {
      this.processQueue();
    }
  }
  
  failTask(taskId, error) {
    // Clear timeout if exists
    if (this.activeExecutions.has(taskId)) {
      clearTimeout(this.activeExecutions.get(taskId).timeoutId);
      this.activeExecutions.delete(taskId);
    }
    
    // Update task state
    this.taskMonitor.updateTask(taskId, 'failed', error);
    
    // Process next tasks
    if (this.taskQueue.length > 0) {
      this.processQueue();
    }
  }
  
  handleTaskTimeout(taskId) {
    this.failTask(taskId, 'Task execution timed out');
  }
  
  getActiveExecutions() {
    return Array.from(this.activeExecutions.values());
  }
  
  getQueueStatus() {
    return {
      queuedTasks: this.taskQueue.length,
      activeTasks: this.activeExecutions.size,
      maxConcurrent: this.options.maxConcurrent
    };
  }
}

module.exports = TaskExecutor;