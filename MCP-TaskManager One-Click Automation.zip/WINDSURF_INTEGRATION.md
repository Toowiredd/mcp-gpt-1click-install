# WindSurf Integration Guide for MCP-TaskManager
*26-02-2025*

## Setup Instructions

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Create Configuration**:
   Create `config.json` in your MCP-TaskManager directory:
   ```json
   {
     "dataDir": "./data",
     "logDir": "./logs",
     "workspace": "./workspace",
     "cascade": {
       "watchDir": "./cascade",
       "responseDir": "./cascade/responses"
     },
     "maxConcurrentTasks": 5
   }
   ```

3. **Start TaskManager**:
   ```bash
   node index.js
   ```

## How WindSurf/Cascade Access Works

WindSurf's Cascade AI can interact with the MCP TaskManager through two mechanisms:

### 1. Command Files
Cascade can write commands to `./cascade/commands.json`:

```json
[
  {
    "id": "cmd-12345",
    "type": "GET_STATUS",
    "params ▋