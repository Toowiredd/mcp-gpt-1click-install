// INTEGRATION: Connect WindSurf IDE with MCP TaskManager
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const TaskManager = require('./taskManager');

// WindSurf integration directory
const WINDSURF_DIR = path.resolve('./windsurf');
const COMMAND_FILE = path.join(WINDSURF_DIR, 'commands.json');
const RESPONSE_FILE = path.join(WINDSURF_DIR, 'responses.json');

// Ensure directory exists
if (!fs.existsSync(WINDSURF_DIR)) {
  fs.mkdirSync(WINDSURF_DIR, { recursive: true });
}

// Initialize command file if it doesn't exist
if (!fs.existsSync(COMMAND_FILE)) {
  fs.writeFileSync(COMMAND_FILE, JSON.stringify([], null, 2));
}

// Initialize response file if it doesn't exist
if (!fs.existsSync(RESPONSE_FILE)) {
  fs.writeFileSync(RESPONSE_FILE, JSON.stringify([], null, 2));
}

class WindsurfIntegration {
  constructor() {
    this.pendingCommands = new Map();
    this.responseQueue = [];
    this.lastCheck = Date.now();
    
    // Process commands every 500ms
    setInterval(() => this.processCommands(), 500);
    
    console.log('WindSurf integration initialized');
  }
  
  // Process commands from file
  processCommands() {
    try {
      // Don't check too frequently
      const now = Date.now();
      if (now - this.lastCheck < 500) return;
      this.lastCheck = now;
      
      // Check if file exists and has content
      if (!fs.existsSync(COMMAND_FILE)) return;
      
      const data = fs.readFileSync(COMMAND_FILE, 'utf8');
      if (!data.trim()) return;
      
      // Parse commands
      const commands = JSON.parse(data);
      if (!Array.isArray(commands) || commands.length === 0) return;
      
      // Clear command file to prevent reprocessing
      fs.writeFileSync(COMMAND_FILE, JSON.stringify([], null, 2));
      
      // Process each command
      for (const cmd of commands) {
        this.executeCommand(cmd).catch(err => {
          console.error('Command execution failed:', err.message);
        });
      }
    } catch (err) {
      console.error('Error processing commands:', err.message);
    }
  }
  
  // Execute a single command
  async executeCommand(cmd) {
    if (!cmd.id || !cmd.action) {
      this.queueResponse({
        id: cmd.id || 'unknown',
        success: false,
        error: 'Invalid command format'
      });
      return;
    }
    
    // Store as pending
    this.pendingCommands.set(cmd.id, {
      action: cmd.action,
      timestamp: Date.now()
    });
    
    try {
      switch (cmd.action) {
        case 'create_task':
          await this.handleCreateTask(cmd);
          break;
        case 'get_status':
          await this.handleGetStatus(cmd);
          break;
        case 'get_history':
          await this.handleGetHistory(cmd);
          break;
        default:
          throw new Error(`Unknown action: ${cmd.action}`);
      }
    } catch (err) {
      this.queueResponse({
        id: cmd.id,
        success: false,
        error: err.message
      });
    }
  }
  
  // Handle create task command
  async handleCreateTask(cmd) {
    const { taskType, params, metadata } = cmd;
    
    if (!taskType || !params) {
      throw new Error('Missing required parameters');
    }
    
    const taskId = TaskManager.createTask(taskType, params, metadata);
    
    this.queueResponse({
      id: cmd.id,
      success: true,
      taskId,
      timestamp: new Date().toISOString()
    });
  }
  
  // Handle get status command
  async handleGetStatus(cmd) {
    const { taskId } = cmd;
    
    if (!taskId) {
      throw new Error('Missing taskId parameter');
    }
    
    try {
      const status = TaskManager.getTaskStatus(taskId);
      
      this.queueResponse({
        id: