// CORE: Task handling with safety mechanisms
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { promisify } = require('util');
const exec = promisify(require('child_process').exec);

// System directories
const DIRS = {
  TASKS: path.resolve('./tasks'),
  COMPLETED: path.resolve('./completed'), 
  FAILED: path.resolve('./failed'),
  LOGS: path.resolve('./logs'),
  PUBLIC: path.resolve('./public')
};

// Create directories if needed
Object.values(DIRS).forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

class TaskManager {
  constructor() {
    this.activeTaskMap = new Map();
    this.taskHistory = [];
    this.stateFile = path.join(DIRS.LOGS, 'manager-state.json');
    
    // Load previous state if exists
    this.loadState();
    
    // Task directory watching
    this.initWatcher();
    
    // Dashboard update
    setInterval(() => this.updateDashboard(), 30000);
    this.updateDashboard();
    
    // Periodic state saving
    setInterval(() => this.saveState(), 60000);
    
    console.log('TaskManager initialized');
  }
  
  // SAFETY: Load state with recovery options
  loadState() {
    try {
      if (fs.existsSync(this.stateFile)) {
        const data = JSON.parse(fs.readFileSync(this.stateFile, 'utf8'));
        this.activeTaskMap = new Map(data.tasks || []);
        this.taskHistory = data.history || [];
        this.verifyTaskIntegrity();
      }
    } catch (err) {
      console.error('Failed to load state:', err.message);
      // Try backup
      try {
        const backupFile = `${this.stateFile}.bak`;
        if (fs.existsSync(backupFile)) {
          const backupData = JSON.parse(fs.readFileSync(backupFile, 'utf8'));
          this.activeTaskMap = new Map(backupData.tasks || []);
          this.taskHistory = backupData.history || [];
          this.verifyTaskIntegrity();
        }
      } catch (backupErr) {
        console.error('Failed to load backup state:', backupErr.message);
        // Reset to empty state
        this.activeTaskMap = new Map();
        this.taskHistory = [];
      }
    }
  }
  
  // SAFETY: Save state with backup
  saveState() {
    const state = {
      tasks: Array.from(this.activeTaskMap.entries()),
      history: this.taskHistory,
      timestamp: new Date().toISOString()
    };
    
    const tempFile = `${this.stateFile}.tmp`;
    const backupFile = `${this.stateFile}.bak`;
    
    try {
      // Create backup of current state if exists
      if (fs.existsSync(this.stateFile)) {
        fs.copyFileSync(this.stateFile, backupFile);
      }
      
      // Write to temp file first
      fs.writeFileSync(tempFile, JSON.stringify(state, null, 2));
      
      // Move to final location
      fs.renameSync(tempFile, this.stateFile);
    } catch (err) {
      console.error('Failed to save state:', err.message);
    }
  }
  
  // VALIDATION: Ensure task data integrity
  verifyTaskIntegrity() {
    // Clear orphaned tasks
    for (const [taskId, task] of this.activeTaskMap.entries()) {
      const taskFile = path.join(DIRS.TASKS, `${taskId}.json`);
      if (!fs.existsSync(taskFile)) {
        this.activeTaskMap.delete(taskId);
        this.taskHistory.push({
          id: taskId,
          status: 'orphaned',
          timestamp: new Date().toISOString()
        });
      }
    }
    
    // Limit history length
    if (this.taskHistory.length > 100) {
      this.taskHistory = this.taskHistory.slice(-100);
    }
  }
  
  // Initialize file watcher
  initWatcher() {
    try {
      fs.watch(DIRS.TASKS, (eventType, filename) => {
        if (eventType === 'rename' && filename && filename.endsWith('.json')) {
          const taskId = path.basename(filename, '.json');
          const taskFile = path.join(DIRS.TASKS, filename);
          
          // Let filesystem finish writing
          setTimeout(() => {
            if (fs.existsSync(taskFile)) {
              this.processTask(taskFile, taskId);
            }
          }, 100);
        }
      });
    } catch (err) {
      console.error('Failed to initialize watcher:', err.message);
      // Fallback to polling
      this.startPolling();
    }
  }
  
  // RECOVERY: Polling fallback if watcher fails
  startPolling() {
    console.log('Falling back to task polling');
    setInterval(() => {
      if (fs.existsSync(DIRS.TASKS)) {
        fs.readdirSync(DIRS.TASKS).forEach(file => {
          if (file.endsWith('.json')) {
            const taskId = path.basename(file, '.json');
            const taskFile = path.join(DIRS.TASKS, file);
            
            if (!this.activeTaskMap.has(taskId)) {
              this.processTask(taskFile, taskId);
            }
          }
        });
      }
    }, 1000);
  }
  
  // Process a task file
  async processTask(taskFile, taskId) {
    try {
      // Read task file
      const taskData = JSON.parse(fs.readFileSync(taskFile, 'utf8'));
      
      // Validate task
      if (!this.validateTask(taskData)) {
        throw new Error('Invalid task format');
      }
      
      // Mark as active
      this.activeTaskMap.set(taskId, {
        ...taskData,
        status: 'processing',
        startTime: new Date().toISOString()
      });
      
      // Update dashboard immediately
      this.updateDashboard();
      
      // Execute task
      const result = await this.executeTask(taskData);
      
      // Update status
      this.activeTaskMap.set(taskId, {
        ...this.activeTaskMap.get(taskId),
        status: 'completed',
        result,
        endTime: new Date().toISOString()
      });
      
      // Move to completed folder
      this.moveTaskFile(taskFile, DIRS.COMPLETED, taskId);
      
      // Update history
      this.taskHistory.push({
        id: taskId,
        type: taskData.type,
        status: 'completed',
        timestamp: new Date().toISOString()
      });
      
      // Save state
      this.saveState();
      
      // Update dashboard
      this.updateDashboard();
      
      return result;
    } catch (err) {
      this.handleTaskError(taskFile, taskId, err);
      return { error: err.message };
    }
  }
  
  // SECURITY: Validate tasks
  validateTask(taskData) {
    if (!taskData || !taskData.type || !taskData.params) {
      return false;
    }
    
    const validTypes = ['process', 'query', 'report', 'backup', 'monitor'];
    if (!validTypes.includes(taskData.type)) {
      return false;
    }
    
    // Type-specific validation
    if (taskData.type === 'process') {
      const { command } = taskData.params;
      if (!command || typeof command !== 'string') {
        return false;
      }
      
      // SECURITY: Prevent command injection
      if (/[;&|`$]/.test(command)) {
        return false;
      }
      
      // Whitelist allowed commands
      const allowedCommands = ['node', 'npm', 'python'];
      const cmdParts = command.split(' ');
      if (!allowedCommands.includes(cmdParts[0])) {
        return false;
      }
    }
    
    return true;
  }
  
  // Task execution
  async executeTask(taskData) {
    switch (taskData.type) {
      case 'process':
        return this.executeProcess(taskData.params);
      case 'query':
        return this.executeQuery(taskData.params);
      case 'report':
        return this.generateReport(taskData.params);
      case 'backup':
        return this.createBackup(taskData.params);
      case 'monitor':
        return this.monitorSystem(taskData.params);
      default:
        throw new Error(`Unknown task type: ${taskData.type}`);
    }
  }
  
  // SECURITY: Execute process with strict limits
  async executeProcess(params) {
    const { command } = params;
    
    try {
      const { stdout, stderr } = await exec(command, {
        timeout: 30000,     // 30 second timeout
        maxBuffer: 1048576  // 1MB output limit
      });
      
      return { stdout, stderr: stderr || null };
    } catch (err) {
      throw new Error(`Process failed: ${err.message}`);
    }
  }
  
  // Execute query task
  async executeQuery(params) {
    // Simplified simulation
    return {
      results: `Query executed: ${JSON.stringify(params)}`,
      timestamp: new Date().toISOString()
    };
  }
  
  // Generate report
  async generateReport(params) {
    const { type, format } = params;
    const reportId = crypto.randomBytes(4).toString('hex');
    const filename = `report_${type}_${Date.now()}.${format || 'json'}`;
    const filePath = path.join(DIRS.PUBLIC, filename);
    
    // Create simple report file
    const data = {
      type,
      generated: new Date().toISOString(),
      data: { message: "Sample report data" }
    };
    
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    
    return {
      reportId,
      filename,
      url: `/public/${filename}`
    };
  }
  
  // Create backup
  async createBackup(params) {
    const { target } = params;
    const backupId = crypto.randomBytes(4).toString('hex');
    const filename = `backup_${target}_${Date.now()}.json`;
    const filePath = path.join(DIRS.PUBLIC, filename);
    
    // Simplified backup creation
    const data = {
      target,
      timestamp: new Date().toISOString(),
      status: "completed"
    };
    
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    
    return {
      backupId,
      filename,
      url: `/public/${filename}`
    };
  }
  
  // Monitor system
  async monitorSystem(params) {
    return {
      timestamp: new Date().toISOString(),
      memory: process.memoryUsage(),
      uptime: process.uptime()
    };
  }
  
  // Handle task errors
  handleTaskError(taskFile, taskId, error) {
    try {
      // Update task status
      this.activeTaskMap.set(taskId, {
        ...this.activeTaskMap.get(taskId),
        status: 'failed',
        error: error.message,
        endTime: new Date().toISOString()
      });
      
      // Move to failed folder
      this.moveTaskFile(taskFile, DIRS.FAILED, taskId);
      
      // Update history
      this.taskHistory.push({
        id: taskId,
        type: this.activeTaskMap.get(taskId).type,
        status: 'failed',
        error: error.message,
        timestamp: new Date().toISOString()
      });
      
      // Update dashboard
      this.updateDashboard();
      
      // Save state
      this.saveState();
    } catch (err) {
      console.error('Error handling task failure:', err.message);
    }
  }
  
  // SAFETY: Move task file with enhanced data
  moveTaskFile(sourcePath, destDir, taskId) {
    try {
      // Get task data
      const taskData = JSON.parse(fs.readFileSync(sourcePath, 'utf8'));
      const taskInfo = this.activeTaskMap.get(taskId);
      
      // Enhance with results/errors
      const enhancedData = {
        ...taskData,
        status: taskInfo.status,
        endTime: taskInfo.endTime,
        result: taskInfo.result,
        error: taskInfo.error
      };
      
      // Write to destination
      const destPath = path.join(destDir, `${taskId}.json`);
      fs.writeFileSync(destPath, JSON.stringify(enhancedData, null, 2));
      
      // Delete original only after successful write
      fs.unlinkSync(sourcePath);
    } catch (err) {
      console.error('Failed to move task file:', err.message);
    }
  }
  
  // VISUAL: Update dashboard for aphantasia support
  updateDashboard() {
    try {
      const activeTasks = Array.from(this.activeTaskMap.entries())
        .map(([id, task]) => ({ id, ...task }));
        
      const recentHistory = this.taskHistory
        .slice(-20)
        .reverse();
      
      let html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="30">
        <title>MCP TaskManager Dashboard</title>
        <style>
          body { font-family: Arial; margin: 0; padding: 20px; background: #f5f5f5; }
          .container { display: flex; flex-wrap: wrap; gap: 20px; }
          .card { background: white; border-radius: 8px; padding: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); flex: 1; min-width: 300px; }
          table { width: 100%; border-collapse: collapse; }
          th, td { text-align: left; padding: 8px; border-bottom: 1px solid #ddd; }
          th { background-color: #f2f2f2; }
          .badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: bold;
            color: white;
          }
          .processing { background-color: #3498db; }
          .completed { background-color: #2ecc71; }
          .failed { background-color: #e74c3c; }
        </style>
      </head>
      <body>
        <h1>MCP TaskManager Dashboard</h1>
        
        <div class="container">
          <div class="card">
            <h2>Active Tasks</h2>
            <table>
              <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Status</th>
                <th>Started</th>
              </tr>`;
      
      if (activeTasks.length === 0) {
        html += `<tr><td colspan="4">No active tasks</td></tr>`;
      } else {
        activeTasks.forEach(task => {
          html += `
          <tr>
            <td>${task.id.substring(0, 8)}...</td>
            <td>${task.type}</td>
            <td><span class="badge ${task.status}">${task.status}</span></td>
            <td>${new Date(task.startTime).toLocaleString()}</td>
          </tr>`;
        });
      }
      
      html += `
            </table>
          </div>
          
          <div class="card">
            <h2>Recent Tasks</h2>
            <table>
              <tr>
                <th>ID</th>
                <th>Type</th>
                <th>Status</th>
                <th>Time</th>
              </tr>`;
      
      if (recentHistory.length === 0) {
        html += `<tr><td colspan="4">No task history</td></tr>`;
      } else {
        recentHistory.forEach(task => {
          html += `
          <tr>
            <td>${task.id.substring(0, 8)}...</td>
            <td>${task.type}</td>
            <td><span class="badge ${task.status}">${task.status}</span></td>
            <td>${new Date(task.timestamp).toLocaleString()}</td>
          </tr>`;
        });
      }
      
      html += `
            </table>
          </div>
        </div>
        
        <div class="card" style="margin-top: 20px;">
          <h2>System Status</h2>
          <p>Last updated: ${new Date().toLocaleString()}</p>
          <p>Total tasks processed: ${this.taskHistory.length}</p>
        </div>
      </body>
      </html>`;
      
      fs.writeFileSync(path.join(DIRS.PUBLIC, 'dashboard.html'), html);
    } catch (err) {
      console.error('Failed to update dashboard:', err.message);
    }
  }
  
  // PUBLIC API: Create a new task
  createTask(type, params, metadata = {}) {
    const taskId = crypto.randomBytes(8).toString('hex');
    
    const task = {
      id: taskId,
      type,
      params,
      metadata: {
        ...metadata,
        created: new Date().toISOString()
      }
    };
    
    if (!this.validateTask(task)) {
      throw new Error('Invalid task configuration');
    }
    
    const taskFile = path.join(DIRS.TASKS, `${taskId}.json`);
    fs.writeFileSync(taskFile, JSON.stringify(task, null, 2));
    
    return taskId;
  }
  
  // PUBLIC API: Get task status
  getTaskStatus(taskId) {
    // Check active tasks
    if (this.activeTaskMap.has(taskId)) {
      return this.activeTaskMap.get(taskId);
    }
    
    // Check completed tasks
    const completedPath = path.join(DIRS.COMPLETED, `${taskId}.json`);
    if (fs.existsSync(completedPath)) {
      return JSON.parse(fs.readFileSync(completedPath, 'utf8'));
    }
    
    // Check failed tasks
    const failedPath = path.join(DIRS.FAILED, `${taskId}.json`);
    if (fs.existsSync(failedPath)) {
      return JSON.parse(fs.readFileSync(failedPath, 'utf8'));
    }
    
    throw new Error(`Task not found: ${taskId}`);
  }
}

module.exports = new TaskManager();