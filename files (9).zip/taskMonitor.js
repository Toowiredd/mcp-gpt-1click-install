// Task Execution Monitor - Auto-reports task status to dashboard

const axios = require('axios');

class TaskMonitor {
  constructor(serverUrl) {
    this.serverUrl = serverUrl;
    this.activeTasks = new Map();
    this.errorCount = 0;
  }
  
  startTask(taskId, taskType) {
    if (!taskId) throw new Error('Invalid taskId');
    
    const startTime = Date.now();
    this.activeTasks.set(taskId, {
      taskType,
      startTime,
      status: 'running'
    });
    
    // Auto-report task started
    this.reportStatus(taskId, 'started');
    
    return {
      complete: (result) => this.completeTask(taskId, result),
      fail: (error) => this.failTask(taskId, error)
    };
  }
  
  completeTask(taskId, result) {
    if (!this.activeTasks.has(taskId)) return false;
    
    const task = this.activeTasks.get(taskId);
    task.endTime = Date.now();
    task.duration = task.endTime - task.startTime;
    task.status = 'completed';
    task.result = result;
    
    this.reportStatus(taskId, 'completed', { 
      duration: task.duration,
      result: JSON.stringify(result).substring(0, 100) // Trim long results
    });
    
    return true;
  }
  
  failTask(taskId, error) {
    if (!this.activeTasks.has(taskId)) return false;
    
    const task = this.activeTasks.get(taskId);
    task.endTime = Date.now();
    task.duration = task.endTime - task.startTime;
    task.status = 'failed';
    task.error = error.message || 'Unknown error';
    
    this.errorCount++;
    
    this.reportStatus(taskId, 'failed', {
      duration: task.duration,
      error: task.error
    });
    
    // Auto-retry logic for specific error types
    if (error.code === 'NETWORK_ERROR' && this.errorCount < 3) {
      console.log(`Auto-retrying task ${taskId} (attempt ${this.errorCount})`);
      // Implement retry logic here
    }
    
    return true;
  }
  
  reportStatus(taskId, status, details = {}) {
    try {
      axios.post(`${this.serverUrl}/api/task-status`, {
        taskId,
        status,
        timestamp: new Date().toISOString(),
        ...details
      }).catch(err => console.error('Failed to report task status:', err.message));
    } catch (err) {
      console.error('Error reporting task status:', err);
    }
  }
}

module.exports = TaskMonitor;