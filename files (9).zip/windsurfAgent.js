// WindSurf Integration - Connects MCP TaskManager with WindSurf IDE

const fs = require('fs');
const path = require('path');
const TaskMonitor = require('./taskMonitor');

class WindSurfAgent {
  constructor(config) {
    this.config = {
      watchPath: './tasks',
      completedPath: './completed',
      errorPath: './errors',
      commandFile: './windsurf-commands.json',
      ...config
    };
    
    this.taskMonitor = new TaskMonitor(this.config.serverUrl || 'http://localhost:3000');
    this.commandQueue = [];
    this.isProcessing = false;
    
    // Create directories if they don't exist
    [this.config.watchPath, this.config.completedPath, this.config.errorPath].forEach(dir => {
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    });
  }
  
  start() {
    console.log('WindSurf Integration Agent started');
    this.watchTaskFolder();
    this.watchCommandFile();
    setInterval(() => this.processCommandQueue(), 1000);
  }
  
  watchTaskFolder() {
    fs.watch(this.config.watchPath, (eventType, filename) => {
      if (eventType === 'rename' && filename) {
        const taskPath = path.join(this.config.watchPath, filename);
        
        // Ensure file exists and has finished writing
        setTimeout(() => {
          if (fs.existsSync(taskPath)) {
            try {
              const taskData = JSON.parse(fs.readFileSync(taskPath, 'utf8'));
              this.queueCommand({
                type: 'EXECUTE_TASK',
                data: taskData,
                source: taskPath
              });
            } catch (err) {
              console.error(`Error processing task file ${filename}:`, err.message);
              this.moveFileToErrors(taskPath);
            }
          }
        }, 100);
      }
    });
  }
  
  watchCommandFile() {
    if (fs.existsSync(this.config.commandFile)) {
      fs.watch(this.config.commandFile, () => {
        try {
          const commands = JSON.parse(fs.readFileSync(this.config.commandFile, 'utf8'));
          if (Array.isArray(commands)) {
            commands.forEach(cmd => this.queueCommand(cmd));
            // Clear the file after reading
            fs.writeFileSync(this.config.commandFile, '[]');
          }
        } catch (err) {
          console.error('Error reading command file:', err.message);
        }
      });
    } else {
      // Create initial command file
      fs.writeFileSync(this.config.commandFile, '[]');
    }
  }
  
  queueCommand(command) {
    this.commandQueue.push({
      ...command,
      timestamp: Date.now()
    });
  }
  
  async processCommandQueue() {
    if (this.isProcessing || this.commandQueue.length === 0) return;
    
    this.isProcessing = true;
    const command = this.commandQueue.shift();
    
    try {
      switch (command.type) {
        case 'EXECUTE_TASK':
          await this.executeTask(command.data, command.source);
          break;
        case 'QUERY_STATUS':
          await this.reportStatusToCascade(command.taskId);
          break;
        default:
          console.warn(`Unknown command type: ${command.type}`);
      }
    } catch (err) {
      console.error(`Error processing command ${command.type}:`, err.message);
    } finally {
      this.isProcessing = false;
    }
  }
  
  async executeTask(taskData, sourcePath) {
    if (!taskData.id || !taskData.type) {
      this.moveFileToErrors(sourcePath);
      return;
    }
    
    const taskHandler = this.taskMonitor.startTask(taskData.id, taskData.type);
    
    try {
      // Here you would implement actual task execution based on taskData.type
      const result = await this.runTaskLogic(taskData);
      
      taskHandler.complete(result);
      if (sourcePath) this.moveFileToCompleted(sourcePath);
      
    } catch (error) {
      taskHandler.fail(error);
      if (sourcePath) this.moveFileToErrors(sourcePath);
    }
  }
  
  async runTaskLogic(taskData) {
    // Implement actual task execution here based on taskData.type
    // This is a placeholder implementation
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (Math.random() > 0.1) { // 90% success rate for demo
          resolve({ success: true, message: `Task ${taskData.id} completed` });
        } else {
          reject(new Error(`Task ${taskData.id} failed randomly`));
        }
      }, 500); 
    });
  }
  
  async reportStatusToCascade(taskId) {
    // Implementation for reporting back to Cascade AI
    const taskInfo = this.taskMonitor.activeTasks.get(taskId) || { status: 'unknown' };
    
    // Write status to a file that Cascade can read
    fs.writeFileSync(
      `./cascade-status-${taskId}.json`, 
      JSON.stringify(taskInfo, null, 2)
    );
  }
  
  moveFileToCompleted(filePath) {
    const filename = path.basename(filePath);
    const targetPath = path.join(this.config.completedPath, filename);
    try {
      fs.renameSync(filePath, targetPath);
    } catch (err) {
      console.error(`Failed to move ${filename} to completed folder:`, err.message);
    }
  }
  
  moveFileToErrors(filePath) {
    const filename = path.basename(filePath);
    const targetPath = path.join(this.config.errorPath, filename);
    try {
      fs.renameSync(filePath, targetPath);
    } catch (err) {
      console.error(`Failed to move ${filename} to errors folder:`, err.message);
    }
  }
}

module.exports = WindSurfAgent;