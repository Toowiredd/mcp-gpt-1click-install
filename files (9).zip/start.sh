#!/bin/bash
# AUTOMATED STARTUP: Single command initialization
# SAFETY: Includes validation checks and rollback procedures

# Terminal colors for visual indicators
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}===== MCP-TaskManager Local Setup =====${NC}"
echo "Date: $(date '+%d-%m-%Y %H:%M')"

# SAFETY: Check if Docker is installed
if ! command -v docker &> /dev/null; then
  echo -e "${RED}ERROR: Docker not found${NC}"
  echo "Install Docker before continuing: https://docs.docker.com/get-docker/"
  exit 1
fi

# SAFETY: Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
  echo -e "${RED}ERROR: Docker Compose not found${NC}"
  echo "Install Docker Compose before continuing"
  exit 1
fi

# Create required directories
echo "Creating directory structure..."
mkdir -p kong/config tasks completed failed logs public

# Create Kong configuration if needed
if [ ! -f "kong/config/kong.yml" ]; then
  echo "Generating Kong configuration..."
  cat > kong/config/kong.yml << 'EOL'
_format_version: "3.0"
services:
  - name: task-manager-api
    url: http://taskmanager:3000
    routes:
      - name: task-api
        paths:
          - /api/tasks
        strip_path: false
    plugins:
      - name: key-auth
      - name: cors
EOL
fi

# SAFETY: Try starting containers with rollback
echo "Starting containers..."
if docker-compose up -d; then
  echo -e "${GREEN}System started successfully${NC}"
  echo -e "MCP TaskManager: http://localhost:3000/dashboard"
  echo -e "Kong API Gateway: http://localhost:8000/api"
  echo -e "Kong Admin: http://localhost:8001"
else
  echo -e "${RED}ERROR: Failed to start containers${NC}"
  echo "Attempting rollback..."
  docker-compose down
  echo "Containers stopped. Check for errors before retrying."
  exit 1
fi

# Success information with concrete visualization
echo -e "${GREEN}==========================================${NC}"
echo -e "System is running in isolated containers"
echo -e "💾 Data persisted in Docker volumes"
echo -e "🔄 Auto-restart enabled for all services"
echo -e "🔍 Health checks running every 30 seconds"
echo -e "${GREEN}==========================================${NC}"