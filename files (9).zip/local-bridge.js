// LOCAL BRIDGE: Connects local IDE tools to val.town serverless functions
const express = require('express');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// SAFETY: Configuration validation
if (!process.env.VAL_API_KEY) {
  console.error("ERROR: Missing VAL_API_KEY environment variable");
  process.exit(1);
}

// DIRECTORIES: Create required folders with permissions
const dirs = ['./tasks', './completed', './failed', './logs'];
dirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o750 });
  }
});

// EXPRESS SERVER: Local API server
const app = express();
app.use(express.json());
const PORT = process.env.PORT || 3000;

// SECURITY: Generate session key
const sessionKey = crypto.randomBytes(32).toString('hex');

// GET/POST FUNCTIONS: Proxies to val.town API
app.post('/api/tasks', async (req, res) => {
  try {
    const { type, params, metadata } = req.body;
    
    const response = await fetch("https://api.val.town/v1/run/@yourusername/createTask", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.VAL_API_KEY}`
      },
      body: JSON.stringify({ type, params, metadata })
    });
    
    const result = await response.json();
    
    if (response.ok) {
      // SAFETY: Mirror task locally for redundancy
      saveTaskLocally(result.taskId, { type, params, metadata, status: "pending" });
      res.json(result);
    } else {
      res.status(response.status).json(result);
    }
  } catch (err) {
    // SAFETY: Error normalization
    logError("Task creation failed", err);
    res.status(500).json({ error: "INTERNAL_ERROR", message: err.message });
  }
});

app.get('/api/tasks/:taskId', async (req, res) => {
  try {
    const { taskId } = req.params;
    
    // Try local cache first
    const localTask = loadTaskLocally(taskId);
    
    // If up-to-date (recently updated), return local version
    if (localTask && localTask._localUpdated > Date.now() - (5 * 60 * 1000)) {
      return res.json(localTask);
    }
    
    // Otherwise fetch from val.town
    const response = await fetch("https://api.val.town/v1/run/@yourusername/getTaskStatus", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.VAL_API_KEY}`
      },
      body: JSON.stringify({ taskId })
    });
    
    const result = await response.json();
    
    if (response.ok) {
      // Update local cache
      updateTaskLocally(taskId, result);
      res.json(result);
    } else {
      res.status(response.status).json(result);
    }
  } catch (err) {
    logError("Get task status failed", err);
    res.status(500).json({ error: "INTERNAL_ERROR", message: err.message });
  }
});

// DASHBOARD: Visual interface for aphantasia support
app.get('/dashboard', (req, res) => {
  const tasks = getAllLocalTasks();
  
  const html = `
  <!DOCTYPE html>
  <html>
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="30">
    <title>AI Task Manager</title>
    <style>
      body { font-family: Arial; line-height: 1.6; margin: 0; padding: 20px; background: #f5f5f5; }
      .card { background: white; border-radius: 8px; padding: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 20px; }
      table { width: 100%; border-collapse: collapse; }
      th, td { text-align: left; padding: 12px; border-bottom: 1px solid #ddd; }
      .badge {
        display: inline-block;
        padding: 4px 8px;
        border-radius: 4px;
        color: white;
        font-weight: bold;
      }
      .pending { background-color: #f39c12; }
      .processing { background-color: #3498db; }
      .completed { background-color: #2ecc71; }
      .failed { background-color: #e74c3c; }
    </style>
  </head>
  <body>
    <h1>AI Task Manager Dashboard</h1>
    
    <div class="card">
      <h2>Recent Tasks</h2>
      <table>
        <tr>
          <th>ID</th>
          <th>Type</th>
          <th>Status</th>
          <th>Created</th>
          <th>Updated</th>
        </tr>
        ${tasks.map(task => `
          <tr>
            <td>${task.id}</td>
            <td>${task.type}</td>
            <td><span class="badge ${task.status}">${task.status}</span></td>
            <td>${new Date(task.metadata?.created).toLocaleString()}</td>
            <td>${new Date(task._localUpdated).toLocaleString()}</td>
          </tr>
        `).join('')}
      </table>
    </div>
    
    <div class="card">
      <h2>Create Task</h2>
      <form id="taskForm">
        <div style="margin-bottom: 10px;">
          <label>Type:</label>
          <select name="type" required>
            <option value="analyze">Analyze Text</option>
            <option value="generate">Generate Content</option>
            <option value="monitor">System Monitor</option>
            <option value="notify">Send Notification</option>
          </select>
        </div>
        
        <div style="margin-bottom: 10px;">
          <label>Parameters (JSON):</label>
          <textarea name="params" rows="5" style="width: 100%" required></textarea>
        </div>
        
        <button type="submit">Create Task</button>
      </form>
    </div>
    
    <script>
      document.getElementById('taskForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const form = e.target;
        const type = form.type.value;
        let params;
        
        try {
          params = JSON.parse(form.params.value);
        } catch (err) {
          alert('Invalid JSON parameters');
          return;
        }
        
        try {
          const res = await fetch('/api/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type, params })
          });
          
          const data = await res.json();
          
          if (res.ok) {
            alert('Task created: ' + data.taskId);
            location.reload();
          } else {
            alert('Error: ' + data.message);
          }
        } catch (err) {
          alert('Failed to create task: ' + err.message);
        }
      });
    </script>
  </body>
  </html>
  `;
  
  res.send(html);
});

// HELPER FUNCTIONS: File system operations
function saveTaskLocally(taskId, taskData) {
  const filePath = path.join('./tasks', `${taskId}.json`);
  try {
    fs.writeFileSync(filePath, JSON.stringify({
      ...taskData,
      _localUpdated: Date.now()
    }, null, 2));
  } catch (err) {
    logError(`Failed to save task ${taskId} locally`, err);
  }
}

function loadTaskLocally(taskId) {
  const pendingPath = path.join('./tasks', `${taskId}.json`);
  const completedPath = path.join('./completed', `${taskId}.json`);
  const failedPath = path.join('./failed', `${taskId}.json`);
  
  for (const filePath of [pendingPath, completedPath, failedPath]) {
    try {
      if (fs.existsSync(filePath)) {
        return JSON.parse(fs.readFileSync(filePath, 'utf8'));
      }
    } catch (err) {
      // Skip if file can't be read
    }
  }
  
  return null;
}

function updateTaskLocally(taskId, taskData) {
  const sourceFolder = './tasks';
  const targetFolder = taskData.status === 'completed' ? './completed' : 
                       taskData.status === 'failed' ? './failed' : './tasks';
  
  // Delete from all folders first
  for (const folder of ['./tasks', './completed', './failed']) {
    const filePath = path.join(folder, `${taskId}.json`);
    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath);
      } catch (err) {
        logError(`Failed to remove task ${taskId} from ${folder}`, err);
      }
    }
  }
  
  // Save to appropriate folder
  const targetPath = path.join(targetFolder, `${taskId}.json`);
  try {
    fs.writeFileSync(targetPath, JSON.stringify({
      ...taskData,
      _localUpdated: Date.now()
    }, null, 2));
  } catch (err) {
    logError(`Failed to update task ${taskId} locally`, err);
  }
}

function getAllLocalTasks() {
  const tasks = [];
  
  for (const folder of ['./tasks', './completed', './failed']) {
    if (fs.existsSync(folder)) {
      fs.readdirSync(folder).forEach(file => {
        if (file.endsWith('.json')) {
          try {
            const task = JSON.parse(fs.readFileSync(path.join(folder, file), 'utf8'));
            tasks.push(task);
          } catch (err) {
            // Skip corrupted files
          }
        }
      });
    }
  }
  
  return tasks.sort((a, b) => 
    (b._localUpdated || 0) - (a._localUpdated || 0)
  );
}

function logError(message, error) {
  const logPath = path.join('./logs', 'errors.log');
  const timestamp = new Date().toISOString();
  const errorMessage = `${timestamp} - ${message}: ${error.message}\n${error.stack}\n\n`;
  
  try {
    fs.appendFileSync(logPath, errorMessage);
  } catch (logErr) {
    console.error('Failed to write to log:', logErr);
  }
  
  console.error(`${message}: ${error.message}`);
}

// START SERVER
app.listen(PORT, () => {
  console.log(`Local bridge running on http://localhost:${PORT}`);
  console.log(`Dashboard available at http://localhost:${PORT}/dashboard`);
});