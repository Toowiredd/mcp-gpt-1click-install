// SAFETY: Health check script
const fs = require('fs');
const path = require('path');

// Verify critical directories exist
const dirs = ['./tasks', './completed', './failed', './logs'];
const missingDirs = dirs.filter(dir => !fs.existsSync(dir));

if (missingDirs.length > 0) {
  console.error(`Missing critical directories: ${missingDirs.join(', ')}`);
  process.exit(1);
}

// Check writes to file system
try {
  const healthFile = path.join('./logs', 'health.log');
  fs.writeFileSync(healthFile, `Health check: ${new Date().toISOString()}\n`);
  process.exit(0);
} catch (err) {
  console.error(`Failed file system check: ${err.message}`);
  process.exit(1);
}