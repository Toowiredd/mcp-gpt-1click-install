// Cascade AI Command Interface - Allows WindSurf's Cascade AI to control MCP TaskManager

const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

class CascadeInterface {
  constructor(config = {}) {
    this.config = {
      taskFolder: './tasks',
      commandFile: './windsurf-commands.json',
      responseFolder: './cascade-responses',
      ...config
    };
    
    // Create folders if they don't exist
    [this.config.taskFolder, this.config.responseFolder].forEach(dir => {
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    });
  }
  
  /**
   * Create a new task from Cascade AI
   * @param {string} taskType - Type of task to execute
   * @param {object} taskParameters - Parameters for the task
   * @param {string} [description] - Optional description
   * @returns {string} Task ID
   */
  createTask(taskType, taskParameters, description = '') {
    // Input validation
    if (!taskType || typeof taskType !== 'string') {
      throw new Error('Task type must be a non-empty string');
    }
    
    if (!taskParameters || typeof taskParameters !== 'object') {
      throw new Error('Task parameters must be an object');
    }
    
    // Create a unique task ID
    const taskId = uuidv4();
    
    // Create task file
    const taskData = {
      id: taskId,
      type: taskType,
      params: taskParameters,
      description,
      createdAt: new Date().toISOString(),
      createdBy: 'CASCADE_AI'
    };
    
    const taskFile = path.join(this.config.taskFolder, `task-${taskId}.json`);
    
    try {
      fs.writeFileSync(taskFile, JSON.stringify(taskData, null, 2));
      console.log(`Created task ${taskId} of type ${taskType}`);
      return taskId;
    } catch (err) {
      console.error('Failed to create task file:', err.message);
      throw new Error(`Failed to create task: ${err.message}`);
    }
  }
  
  /**
   * Send a command to WindSurf agent
   * @param {string} commandType - Type of command
   * @param {object} commandData - Command data
   * @returns {boolean} Success status
   */
  sendCommand(commandType, commandData = {}) {
    try {
      // Read existing commands
      let commands = [];
      if (fs.existsSync(this.config.commandFile)) {
        try {
          commands = JSON.parse(fs.readFileSync(this.config.commandFile, 'utf8'));
          if (!Array.isArray(commands)) commands = [];
        } catch (err) {
          console.error('Error reading command file, creating new one:', err.message);
        }
      }
      
      // Add new command
      commands.push({
        type: commandType,
        ...commandData,
        timestamp: Date.now()
      });
      
      // Write back to file
      fs.writeFileSync(this.config.commandFile, JSON.stringify(commands, null, 2));
      return true;
    } catch (err) {
      console.error('Failed to send command:', err.message);
      return false;
    }
  }
  
  /**
   * Check status of a task
   * @param {string} taskId - ID of task to check
   * @returns {Promise<object>} Task status
   */
  async checkTaskStatus(taskId) {
    if (!taskId) throw new Error('Task ID is required');
    
    // Request status update
    this.sendCommand('QUERY_STATUS', { taskId });
    
    // Wait for response file
    const statusFile = `./cascade-status-${taskId}.json`;
    
    return new Promise((resolve, reject) => {
      // Set timeout to prevent infinite waiting
      const timeout = setTimeout(() => {
        reject(new Error('Timeout waiting for task status'));
      }, 5000);
      
      const checkFile = () => {
        if (fs.existsSync(statusFile)) {
          try {
            clearTimeout(timeout);
            const status = JSON.parse(fs.readFileSync(statusFile, 'utf8'));
            
            // Move to responses folder for record keeping
            const responseFile = path.join(
              this.config.responseFolder,
              `status-${taskId}-${Date.now()}.json`
            );
            
            // Copy instead of move so WindSurf agent can continue using it
            fs.copyFileSync(statusFile, responseFile);
            
            resolve(status);
          } catch (err) {
            reject(new Error(`Error reading status file: ${err.message}`));
          }
        } else {
          // Check again in 100ms
          setTimeout(checkFile, 100);
        }
      };
      
      checkFile();
    });
  }
  
  /**
   * Helper for Cascade to analyze task results
   * @param {string} taskId - ID of completed task
   * @returns {object|null} Task results or null if not found
   */
  getTaskResult(taskId) {
    const completedPath = './completed';
    const taskFile = path.join(completedPath, `task-${taskId}.json`);
    
    if (fs.existsSync(taskFile)) {
      try {
        return JSON.parse(fs.readFileSync(taskFile, 'utf8'));
      } catch (err) {
        console.error(`Error reading task result file: ${err.message}`);
        return null;
      }
    }
    return null;
  }
}

module.exports = CascadeInterface;