// CORE ENGINE: Handles all task operations with safety mechanisms
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { promisify } = require('util');
const exec = promisify(require('child_process').exec);

// SAFETY: System directories with access controls
const DIRS = {
  TASKS: path.resolve('./tasks'),
  COMPLETED: path.resolve('./completed'),
  FAILED: path.resolve('./failed'),
  LOGS: path.resolve('./logs'),
  BACKUPS: path.resolve('./backups'),
  PUBLIC: path.resolve('./public')
};

// Create all required directories with proper permissions
Object.values(DIRS).forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true, mode: 0o750 });
  }
});

class TaskManager {
  constructor() {
    this.activeTaskMap = new Map();
    this.taskHistory = [];
    this.maxHistoryLength = 100;
    this.stateFile = path.join(DIRS.LOGS, 'manager-state.json');
    this.loadState();
    
    // SAFETY: Scheduled data protection
    setInterval(() => this.saveState(), 30000);
    setInterval(() => this.createBackup(), 3600000); // Hourly backup
    
    // Generate visual dashboard every minute
    setInterval(() => this.updateDashboard(), 60000);
    
    // Initialize dashboard on startup
    this.updateDashboard();
  }

  // ROLLBACK: Atomic state saving with backup
  saveState() {
    const state = {
      tasks: Array.from(this.activeTaskMap.entries()),
      history: this.taskHistory,
      timestamp: new Date().toISOString()
    };
    
    const tempFile = `${this.stateFile}.tmp`;
    const backupFile = `${this.stateFile}.bak`;
    
    try {
      // Write to temp file first
      fs.writeFileSync(tempFile, JSON.stringify(state, null, 2));
      
      // Backup current state file if it exists
      if (fs.existsSync(this.stateFile)) {
        fs.copyFileSync(this.stateFile, backupFile);
      }
      
      // Replace with new state
      fs.renameSync(tempFile, this.stateFile);
    } catch (err) {
      fs.appendFileSync(path.join(DIRS.LOGS, 'error.log'), 
        `${new Date().toISOString()} - State save failed: ${err.message}\n`);
    }
  }

  // RECOVERY: Multi-level state recovery
  loadState() {
    try {
      if (fs.existsSync(this.stateFile)) {
        const state = JSON.parse(fs.readFileSync(this.stateFile, 'utf8'));
        this.activeTaskMap = new Map(state.tasks || []);
        this.taskHistory = state.history || [];
        this.verifyTaskIntegrity();
      }
    } catch (err) {
      this.logError(`Primary state load failed: ${err.message}`);
      
      // RECOVERY LEVEL 1: Try backup state
      try {
        const backupFile = `${this.stateFile}.bak`;
        if (fs.existsSync(backupFile)) {
          const backupState = JSON.parse(fs.readFileSync(backupFile, 'utf8'));
          this.activeTaskMap = new Map(backupState.tasks || []);
          this.taskHistory = backupState.history || [];
          this.verifyTaskIntegrity();
          this.logMessage("Recovered from backup state file");
        }
      } catch (backupErr) {
        this.logError(`Backup state load failed: ${backupErr.message}`);
        
        // RECOVERY LEVEL 2: Rebuild from task folders
        this.logMessage("Attempting to rebuild state from task folders");
        this.rebuildStateFromFiles();
      }
    }
  }

  // RECOVERY: Emergency reconstruction from file system
  rebuildStateFromFiles() {
    this.activeTaskMap = new Map();
    this.taskHistory = [];
    
    try {
      // Scan completed tasks
      if (fs.existsSync(DIRS.COMPLETED)) {
        fs.readdirSync(DIRS.COMPLETED).forEach(file => {
          if (file.endsWith('.json')) {
            try {
              const data = JSON.parse(fs.readFileSync(path.join(DIRS.COMPLETED, file), 'utf8'));
              const taskId = path.basename(file, '.json');
              this.taskHistory.push({
                id: taskId,
                type: data.type || 'unknown',
                status: 'completed',
                timestamp: data.processedAt || new Date().toISOString()
              });
            } catch (e) {
              // Skip corrupted files
            }
          }
        });
      }
      
      // Scan failed tasks
      if (fs.existsSync(DIRS.FAILED)) {
        fs.readdirSync(DIRS.FAILED).forEach(file => {
          if (file.endsWith('.json')) {
            try {
              const data = JSON.parse(fs.readFileSync(path.join(DIRS.FAILED, file), 'utf8'));
              const taskId = path.basename(file, '.json');
              this.taskHistory.push({
                id: taskId,
                type: data.type || 'unknown',
                status: 'failed',
                timestamp: data.processedAt || new Date().toISOString()
              });
            } catch (e) {
              // Skip corrupted files
            }
          }
        });
      }
      
      // Scan active tasks
      if (fs.existsSync(DIRS.TASKS)) {
        fs.readdirSync(DIRS.TASKS).forEach(file => {
          if (file.endsWith('.json')) {
            try {
              const data = JSON.parse(fs.readFileSync(path.join(DIRS.TASKS, file), 'utf8'));
              const taskId = path.basename(file, '.json');
              this.activeTaskMap.set(taskId, {
                ...data,
                status: 'processing',
                startTime: new Date().toISOString()
              });
            } catch (e) {
              // Skip corrupted files
            }
          }
        });
      }
      
      this.logMessage("State rebuilt from filesystem - recovered " + 
        this.taskHistory.length + " historical tasks and " + 
        this.activeTaskMap.size + " active tasks");
    } catch (err) {
      this.logError(`Failed to rebuild state: ${err.message}`);
      // Initialize empty state as last resort
      this.activeTaskMap = new Map();
      this.taskHistory = [];
    }
  }

  // SAFETY: Create time-stamped backup of all data
  createBackup() {
    const timestamp = new Date().toISOString().replace(/:/g, '-');
    const backupDir = path.join(DIRS.BACKUPS, timestamp);
    
    try {
      fs.mkdirSync(backupDir, { recursive: true });
      
      // Backup state files
      if (fs.existsSync(this.stateFile)) {
        fs.copyFileSync(this.stateFile, path.join(backupDir, 'state.json'));
      }
      
      // Backup task folders (just the most important data)
      for (const dir of [DIRS.TASKS, DIRS.COMPLETED, DIRS.FAILED]) {
        const targetDir = path.join(backupDir, path.basename(dir));
        fs.mkdirSync(targetDir, { recursive: true });
        
        if (fs.existsSync(dir)) {
          fs.readdirSync(dir).forEach(file => {
            if (file.endsWith('.json')) {
              fs.copyFileSync(path.join(dir, file), path.join(targetDir, file));
            }
          });
        }
      }
      
      // Clean up old backups (keep only last 24)
      this.cleanupOldBackups(24);
      
    } catch (err) {
      this.logError(`Backup creation failed: ${err.message}`);
    }
  }

  // SAFETY: Remove excessive backups to prevent disk space issues
  cleanupOldBackups(keepCount) {
    try {
      if (fs.existsSync(DIRS.BACKUPS)) {
        const backups = fs.readdirSync(DIRS.BACKUPS)
          .filter(file => fs.statSync(path.join(DIRS.BACKUPS, file)).isDirectory())
          .sort(); // Sort by name (which is timestamp-based)
        
        if (backups.length > keepCount) {
          const toDelete = backups.slice(0, backups.length - keepCount);
          toDelete.forEach(dir => {
            this.removeDirRecursive(path.join(DIRS.BACKUPS, dir));
          });
        }
      }
    } catch (err) {
      this.logError(`Backup cleanup failed: ${err.message}`);
    }
  }

  // SAFETY: Careful recursive directory removal
  removeDirRecursive(dirPath) {
    if (fs.existsSync(dirPath)) {
      fs.readdirSync(dirPath).forEach(file => {
        const curPath = path.join(dirPath, file);
        if (fs.statSync(curPath).isDirectory()) {
          this.removeDirRecursive(curPath);
        } else {
          fs.unlinkSync(curPath);
        }
      });
      fs.rmdirSync(dirPath);
    }
  }

  // VALIDATION: Verify all task data is consistent
  verifyTaskIntegrity() {
    // Remove any active tasks that no longer exist as files
    for (const [taskId, task] of this.activeTaskMap.entries()) {
      const taskFile = path.join(DIRS.TASKS, `${taskId}.json`);
      if (!fs.existsSync(taskFile)) {
        this.activeTaskMap.delete(taskId);
        this.taskHistory.push({
          id: taskId,
          status: 'orphaned',
          timestamp: new Date().toISOString()
        });
      }
    }
    
    // Trim history to prevent unbounded growth
    if (this.taskHistory.length > this.maxHistoryLength) {
      this.taskHistory = this.taskHistory.slice(-this.maxHistoryLength);
    }
  }

  // Initialize watchers for task directory
  initializeWatchers() {
    try {
      // Watch task directory for new files
      fs.watch(DIRS.TASKS, (eventType, filename) => {
        if (eventType === 'rename' && filename && filename.endsWith('.json')) {
          try {
            const taskId = path.basename(filename, '.json');
            const taskFile = path.join(DIRS.TASKS, filename);
            
            // Let the file system complete writing
            setTimeout(() => {
              if (fs.existsSync(taskFile)) {
                this.processNewTask(taskFile, taskId);
              }
            }, 100);
          } catch (err) {
            this.logError(`Task watcher error: ${err.message}`);
          }
        }
      });
    } catch (err) {
      this.logError(`Failed to initialize watchers: ${err.message}`);
      
      // RECOVERY: Fall back to polling if watching fails
      this.startPollingForTasks();
    }
  }

  // RECOVERY: Alternative task detection if fs.watch fails
  startPollingForTasks() {
    this.logMessage("Falling back to polling for tasks");
    
    setInterval(() => {
      try {
        if (fs.existsSync(DIRS.TASKS)) {
          fs.readdirSync(DIRS.TASKS).forEach(file => {
            if (file.endsWith('.json')) {
              const taskId = path.basename(file, '.json');
              const taskFile = path.join(DIRS.TASKS, file);
              
              // Only process if not already in active map
              if (!this.activeTaskMap.has(taskId)) {
                this.processNewTask(taskFile, taskId);
              }
            }
          });
        }
      } catch (err) {
        this.logError(`Task polling error: ${err.message}`);
      }
    }, 1000); // Poll every second
  }

  async processNewTask(taskFile, taskId) {
    try {
      // Read and validate task file
      let rawData = fs.readFileSync(taskFile, 'utf8');
      
      // SAFETY: Validate JSON before parsing
      if (!this.isValidJson(rawData)) {
        throw new Error('Invalid JSON format');
      }
      
      const taskData = JSON.parse(rawData);
      
      // VALIDATION: Ensure task format is valid
      if (!this.validateTask(taskData)) {
        throw new Error('Invalid task format');
      }
      
      // Record task in active map
      this.activeTaskMap.set(taskId, {
        ...taskData,
        status: 'processing',
        startTime: new Date().toISOString()
      });
      
      // Update dashboard immediately for visual feedback
      this.updateDashboard();
      
      // Execute task
      const result = await this.executeTask(taskData, taskId);
      
      // Update task status
      this.activeTaskMap.set(taskId, {
        ...this.activeTaskMap.get(taskId),
        status: 'completed',
        result,
        endTime: new Date().toISOString()
      });
      
      // Move to completed directory
      this.moveTaskFile(taskFile, DIRS.COMPLETED, taskId);
      
      // Update history
      this.taskHistory.push({
        id: taskId,
        type: taskData.type || 'unknown',
        status: 'completed',
        timestamp: new Date().toISOString()
      });
      
      // Save state
      this.saveState();
      
      // Update dashboard
      this.updateDashboard();
      
      return result;
    } catch (err) {
      this.handleTaskError(taskFile, taskId, err);
      return { error: err.message };
    }
  }

  // VALIDATION: Check if string is valid JSON
  isValidJson(str) {
    try {
      JSON.parse(str);
      return true;
    } catch (e) {
      return false;
    }
  }

  // VALIDATION: Check task structure
  validateTask(taskData) {
    // Check required fields
    if (!taskData || !taskData.type || !taskData.params) {
      return false;
    }
    
    // Validate task type is allowed
    const allowedTypes = ['process', 'query', 'report', 'backup', 'monitor'];
    if (!allowedTypes.includes(taskData.type)) {
      return false;
    }
    
    // SECURITY: Sanitize and validate parameters based on type
    switch (taskData.type) {
      case 'process':
        // Prevent command injection
        if (typeof taskData.params.command === 'string') {
          if (/[;&|`$]/.test(taskData.params.command)) {
            return false;
          }
          
          // Only allow whitelisted commands
          const allowedCommands = ['node', 'npm', 'python', 'python3'];
          const firstWord = taskData.params.command.split(' ')[0];
          if (!allowedCommands.includes(firstWord)) {
            return false;
          }
        }
        break;
        
      case 'query':
        // Prevent SQL injection
        if (typeof taskData.params.query === 'string') {
          if (/['";]/.test(taskData.params.query)) {
            return false;
          }
        }
        break;
    }
    
    return true;
  }

  async executeTask(taskData, taskId) {
    // Execute different task types
    switch (taskData.type) {
      case 'process':
        return this.executeProcessTask(taskData.params);
      case 'query':
        return this.executeQueryTask(taskData.params);
      case 'report':
        return this.executeReportTask(taskData.params);
      case 'backup':
        return this.executeBackupTask(taskData.params);
      case 'monitor':
        return this.executeMonitorTask(taskData.params);
      default:
        throw new Error(`Unsupported task type: ${taskData.type}`);
    }
  }

  // SAFETY: Execute process with strict controls
  async executeProcessTask(params) {
    const { command } = params;
    
    // SECURITY: Secondary whitelist check
    const allowedCommands = ['node', 'npm', 'python', 'python3'];
    const cmdParts = command.split(' ');
    
    if (!allowedCommands.includes(cmdParts[0])) {
      throw new Error(`Command not allowed: ${cmdParts[0]}`);
    }
    
    try {
      const { stdout, stderr } = await exec(command, { 
        timeout: 30000, // 30 second timeout
        maxBuffer: 1024 * 1024 // 1MB max buffer
      });
      
      return { stdout, stderr: stderr || null };
    } catch (err) {
      throw new Error(`Process execution failed: ${err.message}`);
    }
  }

  async executeQueryTask(params) {
    // Simulate a database query
    const { query, database } = params;
    
    // In a real implementation, you would connect to the database
    return { 
      results: `Query executed on ${database}: "${query}"`,
      timestamp: new Date().toISOString()
    };
  }

  async executeReportTask(params) {
    // Generate a report
    const { type, format } = params;
    
    // Create actual report file
    const reportId = crypto.randomBytes(8).toString('hex');
    const reportFile = `${type}_${Date.now()}.${format}`;
    const reportPath = path.join(DIRS.PUBLIC, reportFile);
    
    // Create a simple report file
    try {
      const reportContent = JSON.stringify({
        reportType: type,
        generatedAt: new Date().toISOString(),
        data: {
          sample: "This is example report data",
          timestamp: Date.now()
        }
      }, null, 2);
      
      fs.writeFileSync(reportPath, reportContent);
      
      return { 
        reportId,
        reportUrl: `/public/${reportFile}`,
        generatedAt: new Date().toISOString()
      };
    } catch (err) {
      throw new Error(`Report generation failed: ${err.message}`);
    }
  }

  async executeBackupTask(params) {
    // Create a backup of specified resources
    const { target, destination } = params;
    const backupId = crypto.randomBytes(8).toString('hex');
    const timestamp = Date.now();
    const backupFileName = `${target}_${timestamp}.backup`;
    
    // Create backup directory if specified destination doesn't exist
    const backupDir = destination || path.join(DIRS.BACKUPS, 'manual');
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    
    const backupPath = path.join(backupDir, backupFileName);
    
    // Simulate backup creation
    try {
      // Create a dummy backup file
      const backupContent = JSON.stringify({
        target,
        createdAt: new Date().toISOString(),
        content: `Simulated backup of ${target}`
      });
      
      fs.writeFileSync(backupPath, backupContent);
      
      const stats = fs.statSync(backupPath);
      
      return {
        backupId,
        backupPath,
        size: stats.size,
        timestamp: new Date().toISOString()
      };
    } catch (err) {
      throw new Error(`Backup creation failed: ${err.message}`);
    }
  }

  async executeMonitorTask(params) {
    // Monitor system resources
    const { resources } = params;
    
    const metrics = {};
    
    // Basic system monitoring
    if (resources.includes('memory')) {
      metrics.memory = process.memoryUsage();
    }
    
    if (resources.includes('cpu')) {
      // Simulate CPU measurement (real implementation would use OS metrics)
      metrics.cpu = { 
        usage: Math.random() * 100,
        cores: require('os').cpus().length
      };
    }
    
    if (resources.includes('disk')) {
      // Simulate disk space check
      metrics.disk = {
        free: "120GB",
        used: "380GB",
        total: "500GB"
      };
    }
    
    return {
      metrics,
      timestamp: new Date().toISOString()
    };
  }

  // ERROR HANDLING: Process task failures
  handleTaskError(taskFile, taskId, error) {
    try {
      // Update task status
      const taskInfo = this.activeTaskMap.get(taskId) || { 
        status: 'unknown', 
        startTime: new Date().toISOString() 
      };
      
      this.activeTaskMap.set(taskId, {
        ...taskInfo,
        status: 'failed',
        error: error.message,
        endTime: new Date().toISOString()
      });
      
      // Move to failed directory
      this.moveTaskFile(taskFile, DIRS.FAILED, taskId);
      
      // Update history
      this.taskHistory.push({
        id: taskId,
        type: taskInfo.type || 'unknown',
        status: 'failed',
        error: error.message,
        timestamp: new Date().toISOString()
      });
      
      // Log error
      this.logError(`Task ${taskId} failed: ${error.message}`);
      
      // Save state
      this.saveState();
      
      // Update dashboard
      this.updateDashboard();
    } catch (err) {
      this.logError(`Error handling task failure: ${err.message}`);
    }
  }

  // SAFETY: Atomic file move with enriched data
  moveTaskFile(sourcePath, destDir, taskId) {
    try {
      const targetPath = path.join(destDir, `${taskId}.json`);
      
      // Read source file
      const taskData = JSON.parse(fs.readFileSync(sourcePath, 'utf8'));
      
      // Add status information
      const taskInfo = this.activeTaskMap.get(taskId);
      const enrichedData = {
        ...taskData,
        status: taskInfo.status,
        processedAt: new Date().toISOString(),
        result: taskInfo.result,
        error: taskInfo.error
      };
      
      // Write to temporary file first
      const tempPath = `${targetPath}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(enrichedData, null, 2));
      
      // Rename to final destination
      fs.renameSync(tempPath, targetPath);
      
      // Remove original file
      fs.unlinkSync(sourcePath);
    } catch (err) {
      this.logError(`Failed to move task file: ${err.message}`);
      
      // RECOVERY: Try simple copy if move fails
      try {
        fs.copyFileSync(sourcePath, path.join(destDir, `${taskId}.json`));
        fs.unlinkSync(sourcePath);
      } catch (fallbackErr) {
        this.logError(`Complete failure moving task file: ${fallbackErr.message}`);
      }
    }
  }

  // Enhanced logging with categories
  logError(message) {
    const logFile = path.join(DIRS.LOGS, 'error.log');
    fs.appendFileSync(logFile, `${new Date().toISOString()} - ERROR - ${message}\n`);
  }

  logMessage(message) {
    const logFile = path.join(DIRS.LOGS, 'system.log');
    fs.appendFileSync(logFile, `${new Date().toISOString()} - INFO - ${message}\n`);
  }

  // VISUAL: Create interactive dashboard HTML - helps with aphantasia
  updateDashboard() {
    try {
      const activeTasks = Array.from(this.activeTaskMap.entries())
        .map(([id, task]) => ({id, ...task}));
      
      const recentHistory = this.taskHistory
        .slice(-20) // Just show most recent 20 entries
        .reverse(); // Newest first
      
      let html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta http-equiv="refresh" content="60"> <!-- Auto-refresh every minute -->
        <title>MCP Task Manager Dashboard</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; margin: 0; padding: 20px; background: #f5f5f5; }
          h1 { color: #333; border-bottom: 2px solid #ddd; padding-bottom: 10px; }
          .container { display: flex; flex-wrap: wrap; gap: 20px; }
          .card { background: white; border-radius: 8px; padding: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); flex: 1; min-width: 300px; }
          table { width: 100%; border-collapse: collapse; }
          th, td { text-align: left; padding: 12px; border-bottom: 1px solid #ddd; }
          th { background-color: #f2f2f2; }
          tr:hover { background-color: #f9f9f9; }
          .status-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-weight: bold;
            color: white;
          }
          .status-processing { background-color: #3498db; } /* Blue */
          .status-completed { background-color: #2ecc71; } /* Green */
          .status-failed { background-color: #e74c3c; } /* Red */
          .status-orphaned { background-color: #95a5a6; } /* Gray */
        </style>
      </head>
      <body>
        <h1>MCP Task Manager Dashboard</h1>
        <div class="container">
          <div class="card">
            <h2>Active Tasks (${activeTasks.length})</h2>
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Started</th>
                </tr>
              </thead>
              <tbody>
      `;

      if (activeTasks.length === 0) {
        html += '<tr><td colspan="4">No active tasks</td></tr>';
      } else {
        activeTasks.forEach(task => {
          const shortId = task.id.substring(0, 8);
          const statusClass = `status-${task.status}`;
          
          html += `
          <tr>
            <td>${shortId}...</td>
            <td>${task.type || 'unknown'}</td>
            <td><span class="status-badge ${statusClass}">${task.status}</span></td>
            <td>${new Date(task.startTime).toLocaleString()}</td>
          </tr>
          `;
        });
      }

      html += `
              </tbody>
            </table>
          </div>
          
          <div class="card">
            <h2>Recent Tasks (${recentHistory.length})</h2>
            <table>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Timestamp</th>
                </tr>
              </thead>
              <tbody>
      `;

      if (recentHistory.length === 0) {
        html += '<tr><td colspan="4">No task history</td></tr>';
      } else {
        recentHistory.forEach(task => {
          const shortId = task.id.substring(0, 8);
          const statusClass = `status-${task.status}`;
          
          html += `
          <tr>
            <td>${shortId}...</td>
            <td>${task.type || 'unknown'}</td>
            <td><span class="status-badge ${statusClass}">${task.status}</span></td>
            <td>${new Date(task.timestamp).toLocaleString()}</td>
          </tr>
          `;
        });
      }

      html += `
              </tbody>
            </table>
          </div>
        </div>
        
        <div class="card" style="margin-top: 20px;">
          <h2>System Status</h2>
          <table>
            <tr>
              <td>Last Updated</td>
              <td>${new Date().toLocaleString()}</td>
            </tr>
            <tr>
              <td>Tasks Processed</td>
              <td>${this.taskHistory.length}</td>
            </tr>
            <tr>
              <td>System Uptime</td>
              <td>${Math.floor(process.uptime() / 60)} minutes</td>
            </tr>
          </table>
        </div>
      </body>
      </html>
      `;

      // Write dashboard to public directory
      fs.writeFileSync(path.join(DIRS.PUBLIC, 'dashboard.html'), html);
      
    } catch (err) {
      this.logError(`Failed to update dashboard: ${err.message}`);
    }
  }

  // PUBLIC API: Create new task
  createTask(type, params, metadata = {}) {
    try {
      // Create unique task ID
      const taskId = crypto.randomBytes(8).toString('hex');
      
      // Create task object
      const task = {
        id: taskId,
        type,
        params,
        metadata: {
          ...metadata,
          createdAt: new Date().toISOString()
        }
      };
      
      // VALIDATION: Check task before saving
      if (!this.validateTask(task)) {
        throw new Error(`Invalid task configuration`);
      }
      
      // Write to task directory
      const taskPath = path.join(DIRS.TASKS, `${taskId}.json`);
      fs.writeFileSync(taskPath, JSON.stringify(task, null, 2));
      
      return taskId;
    } catch (err) {
      this.logError(`Failed to create task: ${err.message}`);
      throw err;
    }
  }

  // PUBLIC API: Get task status
  getTaskStatus(taskId) {
    // Check active tasks
    