// MCP TaskManager - Universal Agent Connector
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');

// SAFETY: Configuration with defaults
const config = {
  gatewayUrl: process.env.GATEWAY_URL || 'http://localhost:8000',
  agentId: process.env.AGENT_ID || crypto.randomBytes(8).toString('hex'),
  agentName: process.env.AGENT_NAME || 'generic-agent',
  apiKey: process.env.API_KEY || 'default-api-key', // SECURITY: Use env vars
  pollingInterval: parseInt(process.env.POLLING_INTERVAL || '5000', 10)
};

// Agent capabilities registry
const capabilities = {
  createTask: async (type, params) => {
    try {
      const response = await axios.post(`${config.gatewayUrl}/api/tasks`, {
        type,
        params
      }, {
        headers: {
          'apikey': config.apiKey,
          'Content-Type': 'application/json',
          'X-Agent-ID': config.agentId
        }
      });
      return response.data;
    } catch (err) {
      // SAFETY: Error normalization
      const errorMsg = err.response?.data?.error || err.message;
      console.error(`Task creation failed: ${errorMsg}`);
      throw new Error(`Task creation failed: ${errorMsg}`);
    }
  },
  
  getTaskStatus: async (taskId) => {
    try {
      const response = await axios.get(`${config.gatewayUrl}/api/tasks/${taskId}`, {
        headers: {
          'apikey': config.apiKey,
          'X-Agent-ID': config.agentId
        }
      });
      return response.data;
    } catch (err) {
      if (err.response?.status === 404) {
        return { status: 'not_found' };
      }
      throw new Error(`Failed to get task status: ${err.message}`);
    }
  },
  
  registerAgent: async () => {
    try {
      const response = await axios.post(`${config.gatewayUrl}/api/agent/register`, {
        agentId: config.agentId,
        agentName: config.agentName,
        capabilities: ['createTask', 'getStatus']
      });
      
      // SECURITY: Store token safely
      if (response.data.token) {
        config.token = response.data.token;
        return true;
      }
      return false;
    } catch (err) {
      console.error(`Agent registration failed: ${err.message}`);
      return false;
    }
  }
};

// Initialize and export
module.exports = capabilities;