// CENTRAL API GATEWAY: Any agent/IDE integration point
const express = require('express');
const WebSocket = require('ws');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const TaskManager = require('./taskManager');

// Agent activity tracking
const activeAgents = new Map();
const sharedState = {
  activeTasks: new Map(),
  lastUpdates: {},
  editHistory: []
};

// Setup API server
const app = express();
const port = process.env.PORT || 3030;
app.use(express.json());

// WEBSOCKET SERVER: Real-time updates
const server = app.listen(port, () => console.log(`Agent Gateway running on port ${port}`));
const wss = new WebSocket.Server({ server });

// AUTHENTICATION: Simple token-based
function generateAgentToken(agentId, agentName) {
  return crypto.createHash('sha256')
    .update(`${agentId}:${agentName}:${Date.now()}`)
    .digest('hex');
}

// AGENT REGISTRATION
app.post('/api/agent/register', (req, res) => {
  const { agentId, agentName, capabilities } = req.body;
  if (!agentId || !agentName) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  
  const token = generateAgentToken(agentId, agentName);
  activeAgents.set(agentId, {
    name: agentName,
    token,
    capabilities: capabilities || [],
    lastSeen: Date.now(),
    activeConnections: 0
  });
  
  res.json({ token, apiEndpoints: [
    '/api/tasks',
    '/api/tasks/:taskId',
    '/api/state',
    '/ws' // WebSocket endpoint
  ]});
});

// TASK API: Universal task management
app.post('/api/tasks', authenticateAgent, (req, res) => {
  const { type, params, metadata } = req.body;
  const agentId = req.agent.id;
  
  try {
    const taskId = TaskManager.createTask(type, params, {
      ...metadata,
      agentId,
      agentName: activeAgents.get(agentId).name
    });
    
    broadcastUpdate('task_created', { taskId, type });
    res.json({ taskId });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// WebSocket handling for real-time updates
wss.on('connection', (ws, req) => {
  let agentId = null;
  
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      
      // AUTHENTICATION
      if (data.type === 'auth') {
        const agent = Array.from(activeAgents.entries())
          .find(([id, info]) => info.token === data.token);
        
        if (!agent) {
          ws.send(JSON.stringify({ type: 'error', message: 'Invalid token' }));
          return;
        }
        
        agentId = agent[0];
        activeAgents.get(agentId).activeConnections++;
        ws.send(JSON.stringify({ type: 'auth_success', agentId }));
        
        // Send current state
        ws.send(JSON.stringify({
          type: 'state_sync',
          data: sharedState
        }));
        
        return;
      }
      
      