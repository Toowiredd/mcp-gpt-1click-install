#!/bin/bash
# Kong Gateway local installation script
# SAFETY: Installs containerized version to prevent system conflicts

# 1. Install Docker if not present
if ! command -v docker &> /dev/null; then
    echo "Installing Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    sudo usermod -aG docker $USER
fi

# 2. Run Kong Gateway container
echo "Starting Kong Gateway..."
docker run -d --name kong-gateway \
  -e "KONG_DATABASE=off" \
  -e "KONG_DECLARATIVE_CONFIG=/kong/declarative/kong.yml" \
  -e "KONG_PLUGINS=key-auth,cors,rate-limiting" \
  -v "$(pwd)/kong/config:/kong/declarative" \
  -p 8000:8000 \
  -p 8001:8001 \
  -p 8443:8443 \
  -p 8444:8444 \
  kong/kong-gateway:3.5

echo "Kong API Gateway running on:"
echo "- API: http://localhost:8000"
echo "- Admin: http://localhost:8001"