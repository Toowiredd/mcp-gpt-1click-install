// CLOUDLESS TASK MANAGER: Val.town serverless function with AI integration
export async function createTask({ type, params, metadata }) {
  if (!type || !params) throw new Error("INVALID_PARAMETERS");
  
  const taskId = crypto.randomUUID().replace(/-/g, '');
  const created = new Date().toISOString();
  
  // SAFETY: Validate task before storage
  const validationResult = validateTaskParams(type, params);
  if (!validationResult.valid) throw new Error(validationResult.reason);
  
  // Store task in val.town KV store
  await DB.put(`task:${taskId}`, {
    id: taskId,
    type,
    params,
    metadata: { ...metadata, created },
    status: "pending"
  });
  
  // AI-TRIGGER: Notify AI processor of new task
  await triggerAiProcessor(taskId);
  
  return { taskId, created };
}

export async function getTaskStatus({ taskId }) {
  if (!taskId) throw new Error("MISSING_TASK_ID");
  
  const task = await DB.get(`task:${taskId}`);
  if (!task) throw new Error("TASK_NOT_FOUND");
  
  return {
    id: task.id,
    status: task.status,
    result: task.result,
    error: task.error,
    created: task.metadata?.created,
    completed: task.completed
  };
}

export async function processTaskWithAi({ taskId }) {
  const task = await DB.get(`task:${taskId}`);
  if (!task) throw new Error("TASK_NOT_FOUND");
  
  try {
    // Update status to processing
    await DB.put(`task:${taskId}`, {
      ...task,
      status: "processing",
      processingStarted: new Date().toISOString()
    });
    
    // PROCESS BASED ON TYPE
    let result;
    switch (task.type) {
      case "analyze":
        result = await analyzeWithAI(task.params);
        break;
      case "generate":
        result = await generateWithAI(task.params);
        break;
      case "monitor":
        result = await monitorSystem(task.params);
        break;
      case "notify":
        result = await sendNotification(task.params);
        break;
      default:
        throw new Error(`UNSUPPORTED_TASK_TYPE: ${task.type}`);
    }
    
    // SAFETY: State validation
    validateResultStructure(result);
    
    // Store completed task
    await DB.put(`task:${taskId}`, {
      ...task,
      status: "completed",
      result,
      completed: new Date().toISOString()
    });
    
    // Store in history (limited retention)
    const history = (await DB.get("task_history") || []).slice(0, 99);
    history.unshift({
      id: taskId,
      type: task.type,
      status: "completed",
      timestamp: new Date().toISOString()
    });
    await DB.put("task_history", history);
    
    return { success: true, taskId };
  } catch (error) {
    // SAFETY: Rollback procedure
    try {
      await DB.put(`task:${taskId}`, {
        ...task,
        status: "failed",
        error: error.message,
        completed: new Date().toISOString()
      });
    } catch (rollbackError) {
      console.error("CRITICAL: Rollback failed", rollbackError);
    }
    
    throw error;
  }
}

// SAFETY: Validate task parameters
function validateTaskParams(type, params) {
  const validators = {
    analyze: p => p.text && typeof p.text === 'string',
    generate: p => p.prompt && typeof p.prompt === 'string',
    monitor: p => Array.isArray(p.metrics),
    notify: p => p.message && p.channel
  };
  
  if (!validators[type]) return { valid: false, reason: "UNKNOWN_TASK_TYPE" };
  return validators[type](params) 
    ? { valid: true }
    : { valid: false, reason: "INVALID_PARAMETERS" };
}

// AI functions using val.town's AI integration
async function analyzeWithAI(params) {
  const { text } = params;
  
  // Val.town AI integration
  const analysis = await fetch("https://api.val.town/v1/ai/complete", {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.VAL_API_KEY}`
    },
    body: JSON.stringify({
      prompt: `Analyze the following text: ${text}`,
      max_tokens: 500
    })
  }).then(r => r.json());
  
  return { analysis: analysis.choices[0].text };
}

async function generateWithAI(params) {
  const { prompt } = params;
  
  const generation = await fetch("https://api.val.town/v1/ai/complete", {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.VAL_API_KEY}`
    },
    body: JSON.stringify({
      prompt,
      max_tokens: 1000
    })
  }).then(r => r.json());
  
  return { generated: generation.choices[0].text };
}

// Other helper functions
async function monitorSystem() {
  // Simplified monitoring
  return { status: "healthy", timestamp: new Date().toISOString() };
}

async function sendNotification(params) {
  // Simulate notification delivery
  return { delivered: true, timestamp: new Date().toISOString() };
}

async function triggerAiProcessor(taskId) {
  // Trigger the AI processor to handle this task
  await fetch(`https://api.val.town/v1/run/@yourusername/processTaskWithAi`, {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      "Authorization": `Bearer ${process.env.VAL_API_KEY}`
    },
    body: JSON.stringify({ taskId })
  });
}

function validateResultStructure(result) {
  if (!result || typeof result !== 'object') {
    throw new Error("INVALID_RESULT_STRUCTURE");
  }
}