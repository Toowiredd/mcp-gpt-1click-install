# WindSurf Cascade AI - MCP TaskManager Integration

## Quick Setup

1. **Install Dependencies**:
   ```bash
   npm install uuid axios
   ```

2. **Copy Files**:
   - Copy `taskMonitor.js`, `windsurfAgent.js`, and `cascadeInterface.js` to your MCP TaskManager root directory

3. **Create Startup Script**:
   Create `startAgent.js` in your root directory:
   
   ```javascript
   const WindSurfAgent = require('./windsurfAgent');
   
   const agent = new WindSurfAgent({
     serverUrl: 'http://your-mcp-server:3000',
     watchPath: './tasks',
     completedPath: './completed',
     errorPath: './errors',
   });
   
   agent.start();
   ```

4. **Start the Agent**:
   ```bash
   node startAgent.js
   ```

## For WindSurf IDE Configuration

In WindSurf IDE, add this configuration to connect Cascade AI:

```json
{
  "extensions": {
    "cascade": {
      "integrations": {
        "mcpTaskManager": {
          "enabled": true,
          "path": "/path/to/mcp-taskmanager",
          "interfaceModule": "cascadeInterface.js"
        }
      }
    }
  }
}
```

## Example Tasks for Cascade AI

### System Monitoring Task
```javascript
const cascadeInterface = require('./cascadeInterface');
const cascade = new CascadeInterface();

// Create server monitoring task
const taskId = cascade.createTask('SYSTEM_MONITOR', {
  servers: ['app-server-1', 'app-server-2', 'db-server'],
  metrics: ['cpu', 'memory', 'disk', 'network'],
  alertThreshold: 80, // alert if usage > 80%
  interval: 60000 // check every minute
}, 'Monitor critical production servers');

// Check status after a few seconds
setTimeout(async () => {
  const status = await cascade.checkTaskStatus(taskId);
  console.log('Task status:', status);
}, 5000);
```

### Database Backup Task
```javascript
const cascadeInterface = require('./cascadeInterface');
const cascade = new CascadeInterface();

// Create backup task
cascade.createTask('DB_BACKUP', {
  database: 'production',
  compressionLevel: 'high',
  destination: 's3://backups/daily/',
  notifyOnComplete: true
}, 'Daily production database backup');
```