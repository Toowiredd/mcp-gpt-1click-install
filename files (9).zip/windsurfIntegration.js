// INTEGRATION: Connect WindSurf IDE with MCP TaskManager
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const TaskManager = require('./taskManager');

// WindSurf integration directory
const WINDSURF_DIR = path.resolve('./windsurf');
const COMMAND_FILE = path.join(WINDSURF_DIR, 'commands.json');
const RESPONSE_FILE = path.join(WINDSURF_DIR, 'responses.json');

// Ensure directory exists
if (!fs.existsSync(WINDSURF_DIR)) {
  fs.mkdirSync(WINDSURF_DIR, { recursive: true });
}

// Initialize command file if it doesn't exist
if (!fs.existsSync(COMMAND_FILE)) {
  fs.writeFileSync(COMMAND_FILE, JSON.stringify([], null, 2));
}

// Initialize response file if it doesn't exist
if (!fs.existsSync(RESPONSE_FILE)) {
  fs.writeFileSync(RESPONSE_FILE, JSON.stringify([], null, 2));
}

class WindsurfIntegration {
  constructor() {
    this.pendingCommands = new Map();
    this.responseQueue = [];
    this.lastCheck = Date.now();
    
    // Process commands every 500ms
    setInterval(() => this.processCommands(), 500);
    
    console.log('WindSurf integration initialized');
  }
  
  // Process commands from file
  processCommands() {
    try {
      // Don't check too frequently
      const now = Date.now();
      if (now - this.lastCheck < 500) return;
      this.lastCheck = now;
      
      // Check if file exists and has content
      if (!fs.existsSync(COMMAND_FILE)) return;
      
      const data = fs.readFileSync(COMMAND_FILE, 'utf8');
      if (!data.trim()) return;
      
      // Parse commands
      const commands = JSON.parse(data);
      if (!Array.isArray(commands) || commands.length === 0) return;
      
      // Clear command file to prevent reprocessing
      fs.writeFileSync(COMMAND_FILE, JSON.stringify([], null, 2));
      
      // Process each command
      for (const cmd of commands) {
        this.executeCommand(cmd).catch(err => {
          console.error('Command execution failed:', err.message);
        });
      }
    } catch (err) {
      console.error('Error processing commands:', err.message);
    }
  }
  
  // Execute a single command
  async executeCommand(cmd) {
    if (!cmd.id || !cmd.action) {
      this.queueResponse({
        id: cmd.id || 'unknown',
        success: false,
        error: 'Invalid command format'
      });
      return;
    }
    
    // Store as pending
    this.pendingCommands.set(cmd.id, {
      action: cmd.action,
      timestamp: Date.now()
    });
    
    try {
      switch (cmd.action) {
        case 'create_task':
          await this.handleCreateTask(cmd);
          break;
        case 'get_status':
          await this.handleGetStatus(cmd);
          break;
        case 'get_history':
          await this.handleGetHistory(cmd);
          break;
        default:
          throw new Error(`Unknown action: ${cmd.action}`);
      }
    } catch (err) {
      this.queueResponse({
        id: cmd.id,
        success: false,
        error: err.message
      });
    }
  }
  
  // Handle create task command
  async handleCreateTask(cmd) {
    const { taskType, params, metadata } = cmd;
    
    if (!taskType || !params) {
      throw new Error('Missing required parameters');
    }
    
    const taskId = TaskManager.createTask(taskType, params, metadata);
    
    this.queueResponse({
      id: cmd.id,
      success: true,
      taskId,
      timestamp: new Date().toISOString()
    });
  }
  
  // Handle get status command
  async handleGetStatus(cmd) {
    const { taskId } = cmd;
    
    if (!taskId) {
      throw new Error('Missing taskId parameter');
    }
    
    try {
      const status = TaskManager.getTaskStatus(taskId);
      
      this.queueResponse({
        id: cmd.id,
        success: true,
        status,
        timestamp: new Date().toISOString()
      });
    } catch (err) {
      throw new Error(`Failed to get status: ${err.message}`);
    }
  }

  // Handle get history command
  async handleGetHistory(cmd) {
    try {
      const history = TaskManager.taskHistory.slice(-20); // Last 20 tasks
      
      this.queueResponse({
        id: cmd.id,
        success: true,
        history,
        timestamp: new Date().toISOString()
      });
    } catch (err) {
      throw new Error(`Failed to get history: ${err.message}`);
    }
  }

  // Queue response for writing
  queueResponse(response) {
    this.responseQueue.push(response);
    this.pendingCommands.delete(response.id);
    
    // Write responses now
    this.writeResponses();
  }
  
  // Write responses to file
  writeResponses() {
    if (this.responseQueue.length === 0) return;
    
    try {
      // Read existing responses
      let responses = [];
      if (fs.existsSync(RESPONSE_FILE)) {
        const data = fs.readFileSync(RESPONSE_FILE, 'utf8');
        responses = JSON.parse(data);
        
        if (!Array.isArray(responses)) {
          responses = [];
        }
      }
      
      // Add new responses
      responses.push(...this.responseQueue);
      
      // Limit response file size
      if (responses.length > 100) {
        responses = responses.slice(-100);
      }
      
      // Write atomically
      const tempFile = `${RESPONSE_FILE}.tmp`;
      fs.writeFileSync(tempFile, JSON.stringify(responses, null, 2));
      fs.renameSync(tempFile, RESPONSE_FILE);
      
      // Clear queue
      this.responseQueue = [];
    } catch (err) {
      console.error('Failed to write responses:', err.message);
    }
  }

  // Clean up old pending commands
  cleanupOldCommands() {
    const now = Date.now();
    const timeout = 3600000; // 1 hour
    
    for (const [id, cmd] of this.pendingCommands.entries()) {
      if (now - cmd.timestamp > timeout) {
        this.pendingCommands.delete(id);
        
        this.queueResponse({
          id,
          success: false,
          error: 'Command timed out',
          timestamp: new Date().toISOString()
        });
      }
    }
  }
}

// Initialize and export
const windsurfIntegration = new WindsurfIntegration();
module.exports = windsurfIntegration;